#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController
@property (strong) IBOutlet NSPathControl *path;
@property (strong) IBOutlet NSButton *go;

@end

