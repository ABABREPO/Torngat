#import "ViewController.h"
typedef NSString* str_t;
#define stringIsNULL(string) (string == nil || [string isEqual:@""] || [string isEqual:nil] || !string || string == 0x0)
#define GO_RET [_go setEnabled:YES]; return;
#include "SSZipArchive.h"
#define BUNDLE_PATH [[NSBundle mainBundle] bundlePath]

@implementation ViewController

NSArray *parseByLine(str_t file) {
    if ([[NSString stringWithContentsOfFile:file encoding:NSUTF8StringEncoding error:nil] isEqual:@""] || [[NSString stringWithContentsOfFile:file encoding:NSUTF8StringEncoding error:nil] isEqual:@"(null)"]) {
        return @[];
    }
    return [[NSString stringWithContentsOfFile:file encoding:NSUTF8StringEncoding error:nil] componentsSeparatedByString:@"\n"];
}

BOOL writeToFile(str_t file, str_t contents) {
    if ([[NSFileManager defaultManager] fileExistsAtPath:file]) {
        NSError *err;
        [contents writeToFile:file atomically:YES encoding:NSUTF8StringEncoding error:&err];
        if (err) {
            return false;
        }
    } else {
        [[NSFileManager defaultManager] createFileAtPath:file contents:nil attributes:nil];
        NSError *err;
        [contents writeToFile:file atomically:YES encoding:NSUTF8StringEncoding error:&err];
        if (err) {
            return false;
        }
    }
    return true;
}

BOOL removeLineFromFile(str_t file, str_t textOnLine, BOOL newlineBefore, BOOL onlyFirst) {
    NSArray *f = parseByLine(file);
    NSArray *ret = @[];
    if ([f isEqual:@[]]) {
        return false;
    }
    if (onlyFirst) {
        int ofo = -1;
        for (int i = 0; i < f.count; ++i) {
            if ([[NSString stringWithFormat:@"%@", [f objectAtIndex:i]] containsString:textOnLine] && ofo == -1) {
                ofo = i;
            }
        }
        for (int i = 0; i < f.count; ++i) {
            if (i != ofo) {
                ret = [ret arrayByAddingObject:[f objectAtIndex:i]];
            }
        }
    } else {
        for (int i = 0; i < f.count; ++i) {
            if (![[NSString stringWithFormat:@"%@", [f objectAtIndex:i]] containsString:textOnLine]) {
                ret = [ret arrayByAddingObject:[f objectAtIndex:i]];
            }
        }
    }
    writeToFile(file, [ret componentsJoinedByString:@"\n"]);
    if([[NSString stringWithContentsOfFile:file encoding:NSUTF8StringEncoding error:nil] isEqual:@"(null)"]) {
        writeToFile(file, @"");
    }
    return true;
}

BOOL directoryExists(str_t where) {
    BOOL dir;
    [[NSFileManager defaultManager] fileExistsAtPath:where isDirectory:&dir];
    return dir;
}

BOOL removeDirectory(str_t where) {
    if (directoryExists(where)) {
        NSDirectoryEnumerator *enumerator = [[NSFileManager defaultManager] enumeratorAtPath:where];
        str_t file;
        while (file = [enumerator nextObject]) {
            NSError *error = nil;
            [[NSFileManager defaultManager] removeItemAtPath:[where stringByAppendingPathComponent:file] error:&error];
            if (error) {
                return false;
            }
        }
        [[NSFileManager defaultManager] removeItemAtPath:where error:nil];
        return true;
    }
    return false;
}

str_t findTorngatDIR(str_t path) {
    BOOL check0 = false;
    BOOL check1 = false;
    BOOL check2 = false;
    NSArray *find = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:path error:nil];
    for (uint64_t i = 0; i < find.count; ++i) {
        if ([[NSString stringWithFormat:@"%@", [find objectAtIndex:i]] isEqual:@"ViewController.m"]) {
            check0 = true;
        } else if ([[NSString stringWithFormat:@"%@", [find objectAtIndex:i]] isEqual:@"empty_list"] || [[NSString stringWithFormat:@"%@", [find objectAtIndex:i]] isEqual:@"empty_list/"]) {
            check1 = true;
        } else if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@/Torngat.xcodeproj/project.pbxproj", path.stringByDeletingLastPathComponent]]) {
            check2 = true;
        }
        if (directoryExists([NSString stringWithFormat:@"%@/%@", path, [find objectAtIndex:i]])) {
            str_t ret = findTorngatDIR([NSString stringWithFormat:@"%@/%@", path, [find objectAtIndex:i]]);
            if (!stringIsNULL(ret)) {
                return ret;
            }
        }
    }
    if (check0 && check1 && check2) {
        return path;
    }
    return NULL;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    removeDirectory([NSString stringWithFormat:@"%@/Torngat/", BUNDLE_PATH]);
    removeDirectory([NSString stringWithFormat:@"%@/Torngat_Files/", BUNDLE_PATH]);
    unlink([NSString stringWithFormat:@"%@/Torngat.zip", BUNDLE_PATH].UTF8String);
}

str_t replaceStr(str_t str, str_t from, str_t to, BOOL all) {
    if (all) {
        return [str stringByReplacingOccurrencesOfString:from withString:to];
    }
    NSRange orig = [str rangeOfString:from];
    if (NSNotFound != orig.location) {
        return [str stringByReplacingCharactersInRange:orig withString:to];
    }
    return str;
}

- (IBAction)go:(id)sender {
    [_go setEnabled:NO];
    unlink([NSString stringWithFormat:@"%@/Torngat.zip", BUNDLE_PATH].UTF8String);
    str_t path = _path.URL.path;
    NSLog(@"User input: %@", path);
    if (stringIsNULL(path)) {
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Failed"];
        [alert setInformativeText:@"No path was supplied."];
        [alert setAlertStyle:NSAlertStyleCritical];
        [alert runModal];
        GO_RET;
    }
    if (![path.pathExtension.lowercaseString isEqual:@"zip"]) {
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Failed"];
        [alert setInformativeText:[NSString stringWithFormat:@"'%@' is not a ZIP file.", path]];
        [alert setAlertStyle:NSAlertStyleCritical];
        [alert runModal];
        GO_RET;
    }
    removeDirectory([NSString stringWithFormat:@"%@/Torngat_Files/", BUNDLE_PATH]);
    [[NSFileManager defaultManager] createDirectoryAtPath:[NSString stringWithFormat:@"%@/Torngat_Files/", BUNDLE_PATH] withIntermediateDirectories:NO attributes:nil error:nil];
    [SSZipArchive unzipFileAtPath:path toDestination:[NSString stringWithFormat:@"%@/Torngat_Files/", BUNDLE_PATH]];
    path = findTorngatDIR([NSString stringWithFormat:@"%@/Torngat_Files/", BUNDLE_PATH]);
    if (stringIsNULL(path)) {
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Failed"];
        [alert setInformativeText:@"Could not locate files."];
        [alert setAlertStyle:NSAlertStyleCritical];
        [alert runModal];
        GO_RET;
    }
    NSLog(@"Found Torngat! %@", path);
    str_t ViewControllerM = [NSString stringWithFormat:@"%@/ViewController.m", path];
    str_t ViewControllerMCont = [NSString stringWithContentsOfFile:ViewControllerM encoding:NSUTF8StringEncoding error:nil];
    str_t empty_list = [NSString stringWithFormat:@"%@/empty_list", path];
    str_t pbxproj = [NSString stringWithFormat:@"%@/Torngat.xcodeproj/project.pbxproj", path.stringByDeletingLastPathComponent];
    str_t pbxprojCont = [NSString stringWithContentsOfFile:pbxproj encoding:NSUTF8StringEncoding error:nil];
    removeDirectory(empty_list);
    [[NSFileManager defaultManager] copyItemAtPath:[NSString stringWithFormat:@"%@", [[NSBundle mainBundle] pathForResource:@"multi_path" ofType:@""]] toPath:[NSString stringWithFormat:@"%@/multi_path", path] error:nil];
    ViewControllerMCont = replaceStr(ViewControllerMCont, @"#include \"empty_list/sploit.h\"", @"#include \"multi_path/sploit.h\"", NO);
    ViewControllerMCont = replaceStr(ViewControllerMCont, @"usedExploit = @\"empty_list\";", @"usedExploit = @\"multi_path\";", YES);
    ViewControllerMCont = replaceStr(ViewControllerMCont, @"[usedExploit isEqual:@\"empty_list\"]", @"[usedExploit isEqual:@\"multi_path\"]", YES);
    ViewControllerMCont = replaceStr(ViewControllerMCont, @"//  empty_list\n", @"//  multi_path\n", YES);
    ViewControllerMCont = replaceStr(ViewControllerMCont, @"printf(\"empty_list credits:\nExploit: i41nbeer\nPost-exploitation: 1GamerDev, Jonathan Levin, Jonathan Seals, xerub, theninjaprawn\n\");", @"printf(\"multi_path credits:\nExploit: i41nbeer\nPost-exploitation: 1GamerDev, Jonathan Levin, Jonathan Seals, xerub, theninjaprawn\n\");", YES);
    ViewControllerMCont = replaceStr(ViewControllerMCont, @"http://1gamerdev.github.io/Torngat-Files/update.html?exploit=empty_list&version=", @"http://1gamerdev.github.io/Torngat-Files/update.html?exploit=multi_path&version=", YES);
    ViewControllerMCont = replaceStr(ViewControllerMCont, @"exploit = @\"empty_list\";", @"exploit = @\"multi_path\";", YES);
    ViewControllerMCont = replaceStr(ViewControllerMCont, @"run_empty_list(&cont);", @"run_multi_path(&cont);", YES);
    NSLog(@"Modified ViewController.m! %@", ViewControllerMCont);
    pbxprojCont = replaceStr(pbxprojCont, @"empty_list", @"multi_path", YES);
    [ViewControllerMCont writeToFile:ViewControllerM atomically:YES encoding:NSUTF8StringEncoding error:nil];
    [pbxprojCont writeToFile:pbxproj atomically:YES encoding:NSUTF8StringEncoding error:nil];
    removeLineFromFile(pbxproj, @"kmem.c", YES, NO);
    pbxprojCont = [NSString stringWithContentsOfFile:pbxproj encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"Modified pbxproj! %@", pbxprojCont);
    [[NSFileManager defaultManager] createDirectoryAtPath:[NSString stringWithFormat:@"%@/Torngat/", BUNDLE_PATH] withIntermediateDirectories:NO attributes:nil error:nil];
    [[NSFileManager defaultManager] copyItemAtPath:path.stringByDeletingLastPathComponent toPath:[NSString stringWithFormat:@"%@/Torngat/%@", BUNDLE_PATH, path.lastPathComponent] error:nil];
    [SSZipArchive createZipFileAtPath:[NSString stringWithFormat:@"%@/Torngat.zip", BUNDLE_PATH] withContentsOfDirectory:[NSString stringWithFormat:@"%@/Torngat/", BUNDLE_PATH]];
    removeDirectory([NSString stringWithFormat:@"%@/Torngat/", BUNDLE_PATH]);
    removeDirectory([NSString stringWithFormat:@"%@/Torngat_Files/", BUNDLE_PATH]);
    str_t op = _path.URL.path;
    [[NSFileManager defaultManager] moveItemAtPath:op toPath:[NSString stringWithFormat:@"._%@.old.%u", _path.URL.path, arc4random()] error:nil];
    unlink(op.UTF8String);
    [[NSFileManager defaultManager] copyItemAtPath:[NSString stringWithFormat:@"%@/Torngat.zip", BUNDLE_PATH] toPath:op error:nil];
    unlink([NSString stringWithFormat:@"%@/Torngat.zip", BUNDLE_PATH].UTF8String);
    NSAlert *alert = [[NSAlert alloc] init];
    [alert addButtonWithTitle:@"Dismiss"];
    [alert setMessageText:@"Success"];
    [alert setInformativeText:[NSString stringWithFormat:@"Overwritten '%@'.", op]];
    [alert setAlertStyle:NSAlertStyleInformational];
    [alert runModal];
    [_path setURL:nil];
    GO_RET;
}

@end
