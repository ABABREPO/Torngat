#ifndef sploit_h
#define sploit_h

mach_port_t run_empty_list(void);
void post_exploitation(mach_port_t tfp0);

#endif
