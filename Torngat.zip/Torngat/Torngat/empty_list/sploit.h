#ifndef sploit_h
#define sploit_h

mach_port_t run_empty_list(int *set);

#endif
