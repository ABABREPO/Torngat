#import <Foundation/Foundation.h>
#include "ku.h"
#include "patchfinder64.h"
#include "QiLin.h"
static vm_address_t get_kernel_base(mach_port_t kernel_task) {
    uint64_t addr = 0xfffffff028004000;
    while (1) {
        char *buf;
        mach_msg_type_number_t sz = 0;
        kern_return_t ret = vm_read(kernel_task, addr, 0x200, (vm_offset_t*)&buf, &sz);
        if (ret) {
            goto next;
        }
        if (*((uint32_t *)buf) == 0xfeedfacf) {
            int ret = vm_read(kernel_task, addr, 0x1000, (vm_offset_t*)&buf, &sz);
            if (ret != KERN_SUCCESS) {
                goto next;
            }
            for (uintptr_t i=addr; i < (addr+0x2000); i+=(sizeof(uintptr_t))) {
                mach_msg_type_number_t sz;
                int ret = vm_read(kernel_task, i, 0x120, (vm_offset_t*)&buf, &sz);
                if (ret != KERN_SUCCESS) {
                    exit(-1);
                }
                if (!strcmp(buf, "__text") && !strcmp(buf+0x10, "__PRELINK_TEXT")) {
                    return addr;
                }
            }
        }
    next:
        addr -= 0x200000;
    }
}
void post_exploitation(mach_port_t tfp0) {
    uint64_t base = get_kernel_base(tfp0);
    init_kernel(base, NULL);
    init_kernel_utils(tfp0);
    init_kernel(base, NULL);
    initQiLin(tfp0, base);
    rootifyMe();
    ShaiHuludMe(0);
    platformizeMe();
    remountRootFS();
}
