#ifndef sploit_h
#define sploit_h

mach_port_t run_multi_path(void);

#endif
