/*
 *
 *   Torngat
 *   Made by 1GamerDev
 *   * MY * code is licensed under DBAD
 *   (c) 2018
 *
 */

//#define guionly
#import "ViewController.h"
#include "kmem.h"
#import "enterprise_codesigning_credits.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#import <sys/utsname.h>
#import "ZipArchive.h"
#import "SSZipArchive.h"
#import "SSZipCommon.h"
#include "async_wake.h"
#include "Reachability.h"
#import "UIImage+Private.h"
#include <spawn.h>
#include <dirent.h>

// used in if statements to compare the user's iOS version
#define SYSTEM_VERSION_EQUAL_TO(v) ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v) ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v) ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v) ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v) ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)

// hex to rgb
#define hex(hex, alphaVal) [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16))/255.0 green:((float)((hex & 0xFF00) >> 8))/255.0 blue:((float)(hex & 0xFF))/255.0 alpha:alphaVal]

// used in if statements to check if the user is disconnected from the internet
#define noWiFi [[Reachability reachabilityForInternetConnection] currentReachabilityStatus] == NotReachable

// button colours
#define bgDisabledColour setBackgroundColor:hex(0xB8B8B8, 1.0)
#define bgBlueColour setBackgroundColor:hex(0x007AFF, 1.0)

// respringDevice(); to respring the user's device
#define respringDevice() [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationFade]; UIViewController *r = [self.storyboard instantiateViewControllerWithIdentifier:@"respringv"]; [self presentViewController:r animated:YES completion:nil]

#define system(arg) popen(arg, "r")

// define unsint as an unsigned int
typedef unsigned int unsint;

BOOL file_exist(char *file) {
    NSString *f = [NSString stringWithFormat:@"%s", file];
    BOOL dir;
    BOOL exist = [[NSFileManager defaultManager] fileExistsAtPath:f isDirectory:&dir];
    return exist && !dir;
}

BOOL dontRespring = FALSE;
NSString *documentsDirectory;
NSString *getDocumentsDirectory() {
    NSArray *paths = NSSearchPathForDirectoriesInDomains
    (NSDocumentDirectory, NSUserDomainMask, YES);
    documentsDirectory = [paths objectAtIndex:0];
    return documentsDirectory;
}
void writeToLocalFile(NSString *name, NSString *contents) {
    getDocumentsDirectory();
    NSString *fileName = [NSString stringWithFormat:@"%@/%@", documentsDirectory, name];
    [contents writeToFile:fileName atomically:NO encoding:NSUTF8StringEncoding error:nil];
}
void removeLocalFile(NSString *name) {
    getDocumentsDirectory();
    NSString *fileName = [NSString stringWithFormat:@"%@/%@", documentsDirectory, name];
    unlink(fileName.UTF8String);
}
void createLocalDirectory(NSString *name) {
    getDocumentsDirectory();
    [[NSFileManager defaultManager] createDirectoryAtPath:[NSString stringWithFormat:@"%@/%@", documentsDirectory, name] withIntermediateDirectories:NO attributes:nil error:nil];
}
NSString *stringWithContentsOfLocalFile(NSString *daName) {
    getDocumentsDirectory();
    return [NSString stringWithContentsOfFile:[NSString stringWithFormat:@"%@/%@", documentsDirectory, daName] encoding:NSUTF8StringEncoding error:nil];
}
NSString *stringWithPathOfLocalFile(NSString *daName) {
    getDocumentsDirectory();
    return [NSString stringWithFormat:@"%@/%@", documentsDirectory, daName];
}
BOOL darkModeIsEnabled(void) {
    getDocumentsDirectory();
    if([[NSString stringWithContentsOfFile:[NSString stringWithFormat:@"%@/darkMode", documentsDirectory] encoding:NSUTF8StringEncoding error:nil] isEqual: @"yes"]) {
        return true;
    } else {
        return false;
    }
}
BOOL remounted() {
    NSError *no;
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/.write_test"]) {
        [[NSFileManager defaultManager] removeItemAtPath:@"/.write_test" error:nil];
        if ([[NSFileManager defaultManager] fileExistsAtPath:@"/.write_test"]) {
            return false;
        }
    }
    [[NSFileManager defaultManager] createFileAtPath:@"/.write_test" contents:nil attributes:nil];
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/.write_test"]) {
        [[NSFileManager defaultManager] removeItemAtPath:@"/.write_test" error:&no];
        if ([[NSFileManager defaultManager] fileExistsAtPath:@"/.write_test"] || no) {
            return false;
        } else {
            return true;
        }
    } else {
        return false;
    }
}
void freeze() {
    kill(f_pid("SpringBoard", 0), SIGSTOP);
}
void unfreeze() {
    kill(f_pid("SpringBoard", 0), SIGCONT);
}
NSString *versionNumber = @"Version 1.4.0";
NSString *NSVN = @"1.4.0";

NSString *bigFullscreenBoiTitle = @"Loading";
NSString *bigFullscreenBoiText = @"Please Wait";

NSString *usedExploit = @"";

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UIButton *gobtn;
@property (strong, nonatomic) IBOutlet UIWebView *web;
@property (strong, nonatomic) IBOutlet UIProgressView *progress;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *loader;
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UIButton *infoBtn;
@property (strong, nonatomic) IBOutlet UILabel *btnTxt;

@end

@implementation ViewController

mach_port_t get_user_client;
mach_port_t get_tfp0;
uint64_t get_kbase;

int cont = -9999999;

- (void)wrongArch {
    //  there's no reason for this to ever be called since 32bit was dropped in ios 11, but just in case.
    UIAlertController *unsupported = [UIAlertController alertControllerWithTitle:@"Unsupported Architecture" message:@"Torngat does not support 32bit devices." preferredStyle:UIAlertControllerStyleAlert];
    [self presentViewController:unsupported animated:YES completion:nil];
}

- (void)viewWillAppear:(BOOL)animated {
    if (SYSTEM_VERSION_LESS_THAN(@"11.0")) {
        exit(0);
    }
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"11.0") && SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(@"11.1.2")) {
        usedExploit = @"async_wake";
    }
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
#ifdef INTEL86
    [self wrongArch];
#endif
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [_alert setHidden:YES];
    [_alert setAlpha:0.0f];
    [_loader setAlpha:0.0f];
    [_progress setAlpha:0.0f];
    [_progress setHidden:YES];
    self.gobtn.backgroundColor = [UIColor colorWithRed:171 green:178 blue:186 alpha:1.0f];
    self.gobtn.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    self.gobtn.layer.shadowOffset = CGSizeMake(0, 0);
    self.gobtn.layer.shadowOpacity = 1.0f;
    self.gobtn.layer.shadowRadius = 5;
    self.gobtn.layer.masksToBounds = YES;
    self.gobtn.layer.cornerRadius = 25.0f;
    self.gobtn.exclusiveTouch = YES;
    documentsDirectory = getDocumentsDirectory();
    if (![[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@/darkMode", documentsDirectory]]) {
        writeToLocalFile(@"darkMode", @"no");;
    }
    if (![[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@/showLoader", documentsDirectory]]) {
        writeToLocalFile(@"showLoader", @"yes");
    }
    if (![[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@/autoExploit", documentsDirectory]]) {
        writeToLocalFile(@"autoExploit", @"yes");
    }
    if (![[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@/resizeBootlogos", documentsDirectory]]) {
        writeToLocalFile(@"resizeBootlogos", @"no");
    }
    [_web loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://1gamerdev.github.io/Torngat-Files/update.html?exploit=async_wake&version=%@", NSVN]]]];
    if ([usedExploit isEqual:@""]) {
        if (SYSTEM_VERSION_LESS_THAN(@"11.0")) {
            exit(0);
        }
        if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"11.0") && SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(@"11.1.2")) {
            usedExploit = @"async_wake";
        }
    }
    if ([stringWithContentsOfLocalFile(@"autoExploit") isEqual: @"yes"]) {
        dispatch_async(dispatch_get_global_queue(0,0), ^{
            printf("%s\n", usedExploit.UTF8String);
            if ([usedExploit isEqual:@"async_wake"]) {
                get_tfp0 = go(&get_user_client, &cont);
            }
        });
        return;
    }
}

NSInteger btnMem = 0;
- (IBAction)infoBtn:(id)sender {
    if (btnMem == 0) {
        [_infoBtn setTitle:versionNumber forState:UIControlStateNormal];
        btnMem = 1;
    } else if (btnMem == 1) {
        [_infoBtn setTitle:@"iOS 11 - 11.1.2" forState:UIControlStateNormal];
        btnMem = 0;
    } else {
        [_infoBtn setTitle:@"iOS 11 - 11.1.2" forState:UIControlStateNormal];
        btnMem = 0;
    }
}

- (IBAction)go:(id)sender {
#ifdef guionly
    UIViewController *Done = [self.storyboard instantiateViewControllerWithIdentifier:@"Done"];
    [self presentViewController:Done animated:YES completion:nil];
#endif
    // keeps away users on unsupported ios versions
    if ([usedExploit isEqual:@""]) {
        UIAlertController *unsupported = [UIAlertController alertControllerWithTitle:@"Unsupported iOS version" message:[NSString stringWithFormat:@"Your iOS version (%@) is unsupported by Torngat.", [[UIDevice currentDevice] systemVersion]] preferredStyle:UIAlertControllerStyleAlert];
        [self presentViewController:unsupported animated:YES completion:nil];
        return;
    }
    UIAlertControllerStyle style;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        style = UIAlertControllerStyleAlert;
    } else {
        style = UIAlertControllerStyleActionSheet;
    }
    UIAlertController *ca = [UIAlertController alertControllerWithTitle:@"Warning" message:@"By using Torngat, you agree that if it causes any damage to your device, you are responsible." preferredStyle:style];
    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Continue" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        if (cont == 1) {
            // Already succeeded
            unlink("/.write_test");
            [_progress setProgress:1.0];
            if (!darkModeIsEnabled()) {[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.1f];dispatch_async(dispatch_get_main_queue(),^{[self presentViewController:[self.storyboard instantiateViewControllerWithIdentifier:@"Done"] animated:YES completion:nil];});});
            [UIView animateWithDuration:0.6f animations:^{
                [_loader setAlpha:0.0f];
            } completion:^(BOOL finished) {
                [_loader stopAnimating];
            }];
            [_progress setProgress:1.0f];
            [_gobtn setEnabled:NO];
        } else {
            [_gobtn setEnabled:NO];
            [_loader startAnimating];
            [_progress setHidden:NO];
            [_progress setProgress:0.6];
            [UIView animateWithDuration:0.5f animations:^{
                [_btnTxt setAlpha:0.0f];
                [_progress setAlpha:1.0f];
            }];
            [UIView animateWithDuration:0.5f animations:^{
                [_loader setAlpha:1.0f];
            }];
            [_loader setHidden:NO];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{[NSThread sleepForTimeInterval:0.1f];dispatch_async(dispatch_get_main_queue(), ^{
                if([stringWithContentsOfLocalFile(@"autoExploit") isEqual: @"yes"]) {
            retry:;
                if (cont == -9999999) {
                    // code to execute while exploit is running
                    goto retry;
                } else if (cont == -888888888) { goto retry; } else if (cont == 1) {} else {
                    [UIView animateWithDuration:0.6f animations:^{
                        [_loader setAlpha:0.0f];
                    } completion:^(BOOL finished) {
                        [_loader stopAnimating];
                    }];
                    [_progress setHidden:YES];
                    [_gobtn setEnabled:NO];
                    [_gobtn setTitle:@"Failed" forState:UIControlStateDisabled];
                }} else {
                    if ([usedExploit isEqual:@"async_wake"]) {
                        //  async_wake
                        get_tfp0 = go(&get_user_client, &cont);
                    }
                }
                unlink("/.write_test");
                if ([[NSFileManager defaultManager] fileExistsAtPath:@"/.write_test"]) {
                    //printf("Error\n");
                    [UIView animateWithDuration:0.6f animations:^{
                        [_loader setAlpha:0.0f];
                    } completion:^(BOOL finished) {
                        [_loader stopAnimating];
                    }];
                    [_progress setHidden:YES];
                    [_gobtn setEnabled:NO];
                    [_gobtn setTitle:@"Failed" forState:UIControlStateDisabled];
                } else {
                    //printf("/.write_test successfully deleted.\n");
                    [_progress setProgress:1.0];
                    if (!darkModeIsEnabled()) {[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
                    //UIViewController *Done = [self.storyboard instantiateViewControllerWithIdentifier:@"Done"];
                    //  SIGABRT happens here sometimes
                    
                    
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.1f];dispatch_async(dispatch_get_main_queue(),^{[self presentViewController:[self.storyboard instantiateViewControllerWithIdentifier:@"Done"] animated:YES completion:nil];});});
                    [UIView animateWithDuration:0.6f animations:^{
                        [_loader setAlpha:0.0f];
                    } completion:^(BOOL finished) {
                        [_loader stopAnimating];
                    }];
                    [_progress setProgress:1.0f];
                    [_gobtn setEnabled:NO];
                }
            });});
        }
    }];
    [ca addAction:ok];
    [ca addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) { exit(0); }]];
    [self presentViewController:ca animated:YES completion:nil];
}

@end

@interface Done ()
@property (strong, nonatomic) IBOutlet UIView *tweaks;
@property (strong, nonatomic) IBOutlet UIView *credits;
@property (strong, nonatomic) IBOutlet UITabBar *tabBar;
@property (strong, nonatomic) IBOutlet UITabBarItem *homeTab;
@property (strong, nonatomic) IBOutlet UITabBarItem *creditsTab;
@property (strong, nonatomic) IBOutlet UITabBarItem *aboutTab;
@property (strong, nonatomic) IBOutlet UIView *about;
@property (strong, nonatomic) IBOutlet UIView *settings;
@property (strong, nonatomic) IBOutlet UITabBarItem *settingsTab;
@property (strong, nonatomic) IBOutlet UIImageView *bg;

@end

@implementation Done

- (void)respring {
    respringDevice();
}

- (void)visualStyle {
    [_tabBar setValue:@(YES) forKeyPath:@"hidesShadow"];
    if (darkModeIsEnabled()) {
        _tabBar.barStyle = UIBarStyleBlack;
        _tabBar.tintColor = hex(0xFF8500, 1.0);
        _tabBar.barTintColor = hex(0x1B2737, 1.0);
    } else {
        _tabBar.barStyle = UIBarStyleDefault;
        _tabBar.tintColor = hex(0x007AFF, 1.0);
        _tabBar.barTintColor = hex(0xF2F2F2, 1.0);
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [self.tweaks setHidden:NO];
    [self.credits setHidden:YES];
    [self.about setHidden:YES];
    [self.settings setHidden:YES];
    _tabBar.delegate = self;
    [_tabBar setSelectedItem:_homeTab];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(visualStyle)     name:@"updatedVisualStyle" object:nil];
    [self visualStyle];
    UIImage *bg = [UIImage imageWithContentsOfFile:@"/private/var/mobile/Library/SpringBoard/LockBackgroundThumbnail.jpg"];
    [_bg setImage:bg];
}

- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item {
    if (item == _homeTab) {
        [self.tweaks setHidden:NO];
        [self.credits setHidden:YES];
        [self.about setHidden:YES];
        [self.settings setHidden:YES];
    } else if (item == _creditsTab) {
        [self.tweaks setHidden:YES];
        [self.credits setHidden:NO];
        [self.about setHidden:YES];
        [self.settings setHidden:YES];
    } else if (item == _aboutTab) {
        [self.tweaks setHidden:YES];
        [self.credits setHidden:YES];
        [self.about setHidden:NO];
        [self.settings setHidden:YES];
    } else if (item == _settingsTab) {
        [self.tweaks setHidden:YES];
        [self.credits setHidden:YES];
        [self.about setHidden:YES];
        [self.settings setHidden:NO];
    } else {
        exit(0);
    }
}

@end

@interface tweaksView ()
@property (strong, nonatomic) IBOutlet UIButton *resbtn;
@property (strong, nonatomic) IBOutlet UIButton *cc;
@property (strong, nonatomic) IBOutlet UIButton *rebootbtn;
@property (strong, nonatomic) IBOutlet UIButton *brb;
@property (strong, nonatomic) IBOutlet UIButton *bub;
@property (strong, nonatomic) IBOutlet UIWebView *web;
@property (strong, nonatomic) IBOutlet UIButton *maskBtn;
@property (strong, nonatomic) IBOutlet UIButton *bootlogo;
@property (strong, nonatomic) IBOutlet UIButton *fontsBtn;
@property (strong, nonatomic) IBOutlet UIButton *badgeBtn;
@property (strong, nonatomic) IBOutlet UIScrollView *scroll;
@property (strong, nonatomic) IBOutlet UIView *sticky;
@property (strong, nonatomic) IBOutlet UIButton *dscb;
@property (strong, nonatomic) IBOutlet UIButton *exit;
@property (strong, nonatomic) IBOutlet UIView *resview;
@property (strong, nonatomic) IBOutlet UIView *brview;
@property (strong, nonatomic) IBOutlet UIView *buview;
@property (strong, nonatomic) IBOutlet UIView *maskview;
@property (strong, nonatomic) IBOutlet UIView *bootlogoview;
@property (strong, nonatomic) IBOutlet UIView *dscbview;
@property (strong, nonatomic) IBOutlet UIView *ccview;
@property (strong, nonatomic) IBOutlet UIView *badgeview;
@property (strong, nonatomic) IBOutlet UIView *fontsview;
@property (strong, nonatomic) IBOutlet UIView *cncv;
@property (strong, nonatomic) IBOutlet UIButton *cncb;

@end

@implementation tweaksView

- (NSString *)getFE:(NSURL *)url{
    NSString *urlString = [url absoluteString];
    NSArray *componentsArray = [urlString componentsSeparatedByString:@"."];
    NSString *fileExtension = [componentsArray lastObject];
    return fileExtension;
}

- (IBAction)bootlogo:(id)sender {
    [self sVC:@"bootlogo"];
}

- (IBAction)exit:(id)sender {
    respringDevice();
}

- (IBAction)dscb:(id)sender {
    [self sVC:@"dockLine"];
}

- (void)applyBtn:(UIButton*)buttonIdentifier really:(int)really c:(int)c {
    if (really == 1) {
        if (darkModeIsEnabled()) {
            buttonIdentifier.backgroundColor = hex(0x544D45, 1.0);
            [buttonIdentifier setTitleColor:hex(0xFFFFFF, 1.0) forState:UIControlStateNormal];
        } else {
            buttonIdentifier.backgroundColor = [UIColor colorWithRed:171 green:178 blue:186 alpha:1.0f];
            [buttonIdentifier setTitleColor:hex(0x000000, 1.0) forState:UIControlStateNormal];
        }
        buttonIdentifier.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
        buttonIdentifier.layer.shadowOffset = CGSizeMake(0, 0);
        buttonIdentifier.layer.shadowOpacity = 1.0f;
        buttonIdentifier.layer.shadowRadius = 5;
        buttonIdentifier.layer.masksToBounds = NO;
        buttonIdentifier.layer.cornerRadius = 10.0f;
    }
    buttonIdentifier.exclusiveTouch = YES;
    if (c == 1) {
        if (darkModeIsEnabled())
            [buttonIdentifier setTitleColor:[UIColor darkTextColor] forState:UIControlStateNormal];
        else
            [buttonIdentifier setTitleColor:hex(0x007AFF, 1.0) forState:UIControlStateNormal];
    }
    struct utsname u;
    uname(&u);
    NSString *device = [NSString stringWithFormat:@"%s", u.machine];
    if ([device isEqual:@"iPhone10,3"] || [device isEqual:@"iPhone10,6"]) {
        [_dscb setEnabled:NO];
        [_dscb bgDisabledColour];
        [_dscbview setAlpha:0.5f];
    }
    if (SYSTEM_VERSION_LESS_THAN(@"11.1")) {
        [_fontsBtn setEnabled:NO];
        [_fontsBtn bgDisabledColour];
        [_fontsview setAlpha:0.5f];
    }
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        [_dscb setEnabled:NO];
        [_dscb bgDisabledColour];
        [_dscbview setAlpha:0.5f];
    }
    if (!remounted()) {
        [_brb setEnabled:NO];
        [_brb bgDisabledColour];
        [_maskBtn setEnabled:NO];
        [_maskBtn bgDisabledColour];
        [_bootlogo setEnabled:NO];
        [_bootlogo bgDisabledColour];
        [_fontsBtn setEnabled:NO];
        [_fontsBtn bgDisabledColour];
        [_cc setEnabled:NO];
        [_cc bgDisabledColour];
        //[_sticky setHidden:YES];
        //[_rebootbtn setHidden:YES];
        [_brview setAlpha:0.5f];
        [_maskview setAlpha:0.5f];
        [_bootlogoview setAlpha:0.5f];
        [_fontsview setAlpha:0.5f];
        [_ccview setAlpha:0.5f];
    }
}

- (void)av:(UIView*)viewID {
    if (darkModeIsEnabled()) {
        viewID.backgroundColor = hex(0xD9D9D9, 1.0);
    } else {
        viewID.backgroundColor = hex(0xE0E0E0, 1.0);
    }
    viewID.layer.masksToBounds = YES;
    viewID.layer.cornerRadius = 10.0f;
}

- (void)visualStyle {
    [self.navigationController.navigationBar setValue:@(YES) forKeyPath:@"hidesShadow"];
    if (darkModeIsEnabled()) {
        [_scroll setIndicatorStyle:UIScrollViewIndicatorStyleWhite];
        [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
        [self.navigationController.navigationBar setBarTintColor:hex(0x1B2737, 1.0)];
        [self.view setBackgroundColor:hex(0x151E29, 1.0)];
        [_sticky setBackgroundColor:hex(0x708090, 0.65)];
    } else {
        [_scroll setIndicatorStyle:UIScrollViewIndicatorStyleBlack];
        [self.navigationController.navigationBar setBarStyle:UIBarStyleDefault];
        //  [self.navigationController.navigationBar setBarTintColor:nil];
        [self.navigationController.navigationBar setBarTintColor:hex(0xF2F2F2, 1.0)];
        [self.view setBackgroundColor:hex(0xFAFAFA, 1.0)];
        [self.sticky setBackgroundColor:hex(0xEBEBF1, 0.65)];
    }
    [self applyBtn:_resbtn really:0 c:1];
    [self applyBtn:_cc really:0 c:1];
    [self applyBtn:_rebootbtn really:1 c:0];
    [self applyBtn:_brb really:0 c:1];
    [self applyBtn:_bub really:0 c:1];
    [self applyBtn:_maskBtn really:0 c:1];
    [self applyBtn:_bootlogo really:0 c:1];
    [self applyBtn:_badgeBtn really:0 c:1];
    [self applyBtn:_dscb really:0 c:1];
    [self applyBtn:_cncb really:0 c:1];
    [self applyBtn:_exit really:1 c:0];
    [self av:_resview];
    [self av:_brview];
    [self av:_buview];
    [self av:_ccview];
    [self av:_dscbview];
    [self av:_maskview];
    [self av:_badgeview];
    [self av:_fontsview];
    [self av:_bootlogoview];
    [self av:_cncv];
    [_exit setBackgroundColor:[UIColor redColor]];
    [_exit setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    if (!file_exist("/System/Library/Fonts/Core/AppleColorEmoji.ttc") && !file_exist("/System/Library/Fonts/Core/AppleColorEmoji@1x.ttc") && file_exist("/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc") && !file_exist("/System/Library/Fonts/Core/AppleColorEmoji@3x.ttc")) {
        [self applyBtn:_fontsBtn really:0 c:1];
    } else {
        [_fontsBtn setEnabled:NO];
        [_fontsBtn bgDisabledColour];
        [_fontsview setAlpha:0.5f];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(visualStyle)     name:@"updatedVisualStyle" object:nil];
    [self visualStyle];
}

- (void)sVC:(NSString*)vc {
    UIViewController *viewController = [self.storyboard instantiateViewControllerWithIdentifier:vc];
    viewController.providesPresentationContextTransitionStyle = YES;
    viewController.definesPresentationContext = YES;
    [viewController setModalPresentationStyle:UIModalPresentationOverFullScreen];
    [self presentViewController:viewController animated:YES completion:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (IBAction)changeResolution:(id)sender {
    [self sVC:@"res"];
}

- (IBAction)blockRevokes:(id)sender {
    [self sVC:@"blockRevokes"];
}

- (IBAction)blockUpdates:(id)sender {
    [self sVC:@"blockUpdates"];
}

- (IBAction)masks:(id)sender {
    [self sVC:@"Masks"];
}

- (IBAction)badge:(id)sender {
    [self sVC:@"badges"];
}

- (IBAction)fonts:(id)sender {
    [self sVC:@"fonts"];
}

- (IBAction)cnc:(id)sender {
    [self sVC:@"layout"];
}

- (IBAction)exitApp:(id)sender {
    setgid(501);
    setuid(501);
    setegid(501);
    seteuid(501);
    exit(0);
    assert(NO);
}

- (void)request:(NSString *)address {
    NSURL *url = [NSURL URLWithString:address];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
    [_web loadRequest:urlRequest];
}

- (void)viewDidLayoutSubviews {
    if (dontRespring == FALSE) {
        self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width, (_resview.frame.size.height * 10) + 44 + _sticky.frame.size.height + _exit.frame.size.height + _rebootbtn.frame.size.height);
    } else {
        self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width, (_resview.frame.size.height * 10) + 44 + _exit.frame.size.height + _rebootbtn.frame.size.height);
    }
}

@end

@interface blockRevokes ()
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *alertTitle;
@property (strong, nonatomic) IBOutlet UITextView *alertText;
@property (strong, nonatomic) IBOutlet UIButton *dismissAlertBtn;

@end

@implementation blockRevokes

- (void)calert:(NSString*)alertTitle alertMessage:(NSString*)alertMessage dismissButton:(NSString*)dismissButton buttonVis:(int)buttonVis dismissBtnAction:(SEL)dismissBtnAction {
    [_dismissAlertBtn setExclusiveTouch:YES];
    [_cancel setEnabled:NO];
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alertTitle setText:alertTitle];
    [_alertText setText:alertMessage];
    if (buttonVis == 0) {
        [_dismissAlertBtn setHidden:YES];
    } else if (buttonVis == 1) {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:@selector(calertd) forControlEvents:UIControlEventTouchUpInside];
    } else {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:dismissBtnAction forControlEvents:UIControlEventTouchUpInside];
    }
    [_alert setHidden:NO]; [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)calertd {
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];});});
    [_cancel setEnabled:YES];
}

- (IBAction)xBtnPressed:(id)sender {
    [self calertd];
}

- (void)check {
    if ([[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] containsString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd ocsp.apple.com oscp.apple.com"]) {
        [_block setTitle:@"Unblock" forState:UIControlStateNormal];
    } else if ([[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] containsString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd ocsp.apple.com oscp.apple.com"]) {
        [_block setTitle:@"Block" forState:UIControlStateNormal];
    } else {
        [_block setTitle:@"Block" forState:UIControlStateNormal];
    }
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (void)viewWillAppear:(BOOL)animated {
    [self applyBtn:_block];
    [self applyBtn:_cancel];
    [self check];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
}

- (IBAction)cancel:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)block:(id)sender {
    if ([[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] containsString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd ocsp.apple.com oscp.apple.com"]) {
        [[[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] stringByReplacingOccurrencesOfString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd ocsp.apple.com oscp.apple.com" withString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd disabledblockrevokes.apple.com"] writeToFile:@"/etc/hosts" atomically:YES encoding:NSUTF8StringEncoding error:nil];
        [self calert:@"Success" alertMessage:@"Enterprise revocations have been unblocked." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
        [self check];
    } else if ([[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] containsString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd disabledblockrevokes.apple.com"]) {
        [[[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] stringByReplacingOccurrencesOfString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd disabledblockrevokes.apple.com" withString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd ocsp.apple.com oscp.apple.com"] writeToFile:@"/etc/hosts" atomically:YES encoding:NSUTF8StringEncoding error:nil];
        [self calert:@"Success" alertMessage:@"Enterprise revocations have been blocked." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
        [self check];
    } else {
        NSString *str = [NSString stringWithFormat:@"%@\n127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd ocsp.apple.com oscp.apple.com", [NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil]];
        [str writeToFile:@"/etc/hosts" atomically:YES encoding:NSUTF8StringEncoding error:nil];
        [self calert:@"Success" alertMessage:@"Enterprise revocations have been blocked." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
        [self check];
    }
}

@end

@interface blockUpdates ()
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *alertTitle;
@property (strong, nonatomic) IBOutlet UITextView *alertText;
@property (strong, nonatomic) IBOutlet UIButton *dismissAlertBtn;
@property (strong, nonatomic) IBOutlet UITextView *desc;
@property (strong, nonatomic) IBOutlet UIButton *tvOSBTN;

@end

@implementation blockUpdates

- (void)calert:(NSString*)alertTitle alertMessage:(NSString*)alertMessage dismissButton:(NSString*)dismissButton buttonVis:(int)buttonVis dismissBtnAction:(SEL)dismissBtnAction {
    [_dismissAlertBtn setExclusiveTouch:YES];
    [_cancel setEnabled:NO];
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alertTitle setText:alertTitle];
    [_alertText setText:alertMessage];
    if (buttonVis == 0) {
        [_dismissAlertBtn setHidden:YES];
    } else if (buttonVis == 1) {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:@selector(calertd) forControlEvents:UIControlEventTouchUpInside];
    } else {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:dismissBtnAction forControlEvents:UIControlEventTouchUpInside];
    }
    [_alert setHidden:NO]; [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)calertd {
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];});});
    [_cancel setEnabled:YES];
}

- (IBAction)xBtnPressed:(id)sender {
    [self calertd];
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (IBAction)tvOSShit:(id)sender {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://github.com/1GamerDev/Torngat-Files/raw/master/tvOS.mobileconfig"]];
    [self calert:@"Success" alertMessage:@"OTA Updates have been blocked." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
}

- (void)check {
    if (!remounted()) {
        return;
    } else {
    if ([[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] containsString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd mesu.apple.com"]) {
        [_block setTitle:@"Unblock" forState:UIControlStateNormal];
    } else if ([[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] containsString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd disabledblockupdates.apple.com"]) {
        [_block setTitle:@"Block" forState:UIControlStateNormal];
    } else {
        [_block setTitle:@"Block" forState:UIControlStateNormal];
    }
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [self applyBtn:_block];
    [self applyBtn:_tvOSBTN];
    [self applyBtn:_cancel];
    [self check];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
}

- (IBAction)cancel:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)block:(id)sender {
    if ([[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] containsString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd mesu.apple.com"]) {
        [[[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] stringByReplacingOccurrencesOfString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd mesu.apple.com" withString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd disabledblockupdates.apple.com"] writeToFile:@"/etc/hosts" atomically:YES encoding:NSUTF8StringEncoding error:nil];
        [self calert:@"Success" alertMessage:@"OTA Updates have been unblocked." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
        [self check];
    } else if ([[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] containsString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd disabledblockupdates.apple.com"]) {
        [[[NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil] stringByReplacingOccurrencesOfString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd disabledblockupdates.apple.com" withString:@"127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd mesu.apple.com"] writeToFile:@"/etc/hosts" atomically:YES encoding:NSUTF8StringEncoding error:nil];
        [self calert:@"Success" alertMessage:@"OTA Updates have been blocked." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
        [self check];
    } else {
        NSString *str = [NSString stringWithFormat:@"%@\n127.0.0.1 donteditthisentry.torngat.1gamerdev.rf.gd mesu.apple.com", [NSString stringWithContentsOfFile:@"/etc/hosts" encoding:NSUTF8StringEncoding error:nil]];
        [str writeToFile:@"/etc/hosts" atomically:YES encoding:NSUTF8StringEncoding error:nil];
        [self calert:@"Success" alertMessage:@"OTA Updates have been blocked." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
        [self check];
    }
}

@end

@interface res ()
@property (strong, nonatomic) IBOutlet UITextField *h;
@property (strong, nonatomic) IBOutlet UITextField *w;
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *alertTitle;
@property (strong, nonatomic) IBOutlet UITextView *alertText;
@property (strong, nonatomic) IBOutlet UIButton *dismissAlertBtn;
@property (strong, nonatomic) IBOutlet UIButton *xBtn;

@end

@implementation res

- (void)calert:(NSString*)alertTitle alertMessage:(NSString*)alertMessage dismissButton:(NSString*)dismissButton buttonVis:(int)buttonVis dismissBtnAction:(SEL)dismissBtnAction {
    [_dismissAlertBtn setExclusiveTouch:YES];
    [_cancel setEnabled:NO];
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alertTitle setText:alertTitle];
    [_alertText setText:alertMessage];
    if (buttonVis == 0) {
        [_dismissAlertBtn setHidden:YES];
    } else if (buttonVis == 1) {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:@selector(calertd) forControlEvents:UIControlEventTouchUpInside];
    } else {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:dismissBtnAction forControlEvents:UIControlEventTouchUpInside];
    }
    [_alert setHidden:NO]; [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)calertd {
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];});});
    [_cancel setEnabled:YES];
}

- (IBAction)xBtnPressed:(id)sender {
    [self calertd];
}

- (IBAction)dismissKeyboard:(id)sender {
    [self.view endEditing:YES];
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (NSString *)machineName {
    struct utsname systemInfo;
    uname(&systemInfo);
    return [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
}

- (void)viewWillAppear:(BOOL)animated {
    [self applyBtn:_change];
    [self applyBtn:_cancel];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat screenWidth = screenRect.size.width;
    CGFloat screenHeight = screenRect.size.height;
    if (file_exist("/var/mobile/Library/Preferences/com.apple.iokit.IOMobileGraphicsFamily.plist")) {
        NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:@"/var/mobile/Library/Preferences/com.apple.iokit.IOMobileGraphicsFamily.plist"];
        _w.text = [NSString stringWithFormat:@"%@", [d valueForKey:@"canvas_width"]];
        _h.text = [NSString stringWithFormat:@"%@", [d valueForKey:@"canvas_height"]];
    } else {
        _w.text = [NSString stringWithFormat:@"%i", (int)screenWidth];
        _h.text = [NSString stringWithFormat:@"%i", (int)screenHeight];
    }
}

- (IBAction)cancel:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)continueChangeRes {
    [self calertd];
    if (file_exist("/var/mobile/Library/Preferences/com.apple.iokit.IOMobileGraphicsFamily.plist")) {
    NSString *width = _w.text;
    NSString *height = _h.text;
    width = [width stringByReplacingOccurrencesOfString:@"px" withString:@""];
    height = [height stringByReplacingOccurrencesOfString:@"px" withString:@""];
    NSMutableDictionary *res = [NSMutableDictionary dictionaryWithContentsOfFile:@"/var/mobile/Library/Preferences/com.apple.iokit.IOMobileGraphicsFamily.plist"];
    [res setValue:height forKey:@"canvas_height"];
    [res setValue:width forKey:@"canvas_width"];
    [res writeToFile:@"/var/mobile/Library/Preferences/com.apple.iokit.IOMobileGraphicsFamily.plist" atomically:YES];
    [self calertd];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [NSThread sleepForTimeInterval:0.6f];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self calert:@"Success" alertMessage:@"Please reboot your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
        });
    });
    } else {
        NSString *width = _w.text;
        NSString *height = _h.text;
        width = [width stringByReplacingOccurrencesOfString:@"px" withString:@""];
        height = [height stringByReplacingOccurrencesOfString:@"px" withString:@""];
        NSString *res = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"UTF-8\"?><!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\"><plist version=\"1.0\"><dict><key>canvas_height</key><integer>%@</integer><key>canvas_width</key><integer>%@</integer></dict></plist>", height, width];
        [res writeToFile:@"/var/mobile/Library/Preferences/com.apple.iokit.IOMobileGraphicsFamily.plist" atomically:YES];
        [self calertd];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [NSThread sleepForTimeInterval:0.6f];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self calert:@"Success" alertMessage:@"Please reboot your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
            });
        });
    }
}

- (IBAction)change:(id)sender {
    NSString *width = _w.text;
    NSString *height = _h.text;
    width = [width stringByReplacingOccurrencesOfString:@"px" withString:@""];
    height = [height stringByReplacingOccurrencesOfString:@"px" withString:@""];
    if (width != NULL && height != NULL && ![width isEqual: @""] && ![height  isEqual: @""]) {
        NSCharacterSet* notDigits = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
        if ([width rangeOfCharacterFromSet:notDigits].location == NSNotFound && [height rangeOfCharacterFromSet:notDigits].location == NSNotFound) {
            if (![width containsString:@"."] && ![height containsString:@"."]) {
                [self calert:@"Confirmation" alertMessage:@"Changing your resolution may cause unintended side-effects or even stop your device from functioning.  Are you sure you'd like to continue?  (Please make sure you have a backup of your data, because if something goes wrong, you'll have to restore your device via iCloud then load the backup)" dismissButton:@"Continue" buttonVis:2 dismissBtnAction:@selector(continueChangeRes)];
            } else {
                [self calert:@"Error" alertMessage:@"Your width / height may not contain a decimal point." dismissButton:@"Dismiss" buttonVis:0 dismissBtnAction:nil];
            }
        } else {
            [self calert:@"Error" alertMessage:@"Your width / height may only be numeric." dismissButton:@"Dismiss" buttonVis:0 dismissBtnAction:nil];
        }
    } else {
        [self calert:@"Error" alertMessage:@"Please provide the width and height of your new resolution." dismissButton:@"Dismiss" buttonVis:0 dismissBtnAction:nil];
    }
}

@end

@interface cc ()
@property (strong, nonatomic) IBOutlet UIButton *e1btn;
@property (strong, nonatomic) IBOutlet UIButton *d1btn;
@property (strong, nonatomic) IBOutlet UISlider *audio;
@property (strong, nonatomic) IBOutlet UISlider *brightness;
@property (strong, nonatomic) IBOutlet UIButton *e2btn;
@property (strong, nonatomic) IBOutlet UIScrollView *scroll;
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *shortDesc;
@property (strong, nonatomic) IBOutlet UILabel *desc;
@property (strong, nonatomic) IBOutlet UILabel *audioVal;
@property (strong, nonatomic) IBOutlet UILabel *brightnessVal;
@property (strong, nonatomic) IBOutlet UILabel *customisationText;
@property (strong, nonatomic) IBOutlet UILabel *brightnessModuleText;
@property (strong, nonatomic) IBOutlet UILabel *audioModuleText;
@property (strong, nonatomic) IBOutlet UITextView *cusomisationDescription;

@end

@implementation cc

NSString *cc_s1_on;
char *cc_s1_on_char;

- (void)calert {
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    UIViewController *viewController = [self.storyboard instantiateViewControllerWithIdentifier:@"bigFullscreenBoi"];
    viewController.providesPresentationContextTransitionStyle = YES;
    viewController.definesPresentationContext = YES;
    [viewController setModalPresentationStyle:UIModalPresentationOverFullScreen];
    [self presentViewController:viewController animated:NO completion:nil];
}

- (void)e1go:(NSString *)path {
    NSError *error;
    NSData *data = [NSData dataWithContentsOfFile:path];
    id plistFile = [NSPropertyListSerialization propertyListWithData:data options:0 format:NULL error:&error];
    NSData *asXML = [NSPropertyListSerialization dataWithPropertyList:plistFile format:NSPropertyListXMLFormat_v1_0 options:0 error:&error];
    NSLog(@"%@\n", [[NSString alloc] initWithData:asXML encoding:NSUTF8StringEncoding]);
    if (error) {
        bigFullscreenBoiTitle = @"Error";
        bigFullscreenBoiText = nil;
        [self calert];
        return;
    }
    NSArray *strr = [[[NSString alloc] initWithData:asXML encoding:NSUTF8StringEncoding] componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSLog(@"%@\n", strr);
    NSString *str = [[strr componentsJoinedByString:@""] stringByReplacingOccurrencesOfString:@"<key>fixed</key><array><string>com.apple.control-center.ConnectivityModule</string><string>com.apple.mediaremote.controlcenter.nowplaying</string><string>com.apple.control-center.OrientationLockModule</string><string>com.apple.control-center.DoNotDisturbModule</string><string>com.apple.control-center.DisplayModule</string><string>com.apple.control-center.AudioModule</string><string>com.apple.mediaremote.controlcenter.airplaymirroring</string></array>" withString:@"<key>fixed</key><array></array>"];
    NSLog(@"%@\n", str);
    str = [str stringByReplacingOccurrencesOfString:@"<key>user-enabled</key><array>" withString:@"<key>user-enabled</key><array><string>com.apple.control-center.ConnectivityModule</string><string>com.apple.mediaremote.controlcenter.nowplaying</string><string>com.apple.control-center.OrientationLockModule</string><string>com.apple.control-center.DoNotDisturbModule</string><string>com.apple.control-center.DisplayModule</string><string>com.apple.control-center.AudioModule</string><string>com.apple.mediaremote.controlcenter.airplaymirroring</string>"];
    NSLog(@"%@\n", str);
    str = [str stringByReplacingOccurrencesOfString:@"<?xmlversion=\"1.0\"encoding=\"UTF-8\"?><!DOCTYPEplistPUBLIC\"-//Apple//DTDPLIST1.0//EN\"\"http://www.apple.com/DTDs/PropertyList-1.0.dtd\"><plistversion=\"1.0\">" withString:@"<?xml version=\"1.0\" encoding=\"UTF-8\"?><!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\"><plist version=\"1.0\">"];
    NSLog(@"%@\n", str);
    [str writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
    bigFullscreenBoiTitle = @"Success";
    bigFullscreenBoiText = @"Please respring your device.";
    [self calert];
    NSLog(@"%@", [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil]);
    [[NSFileManager defaultManager] createFileAtPath:cc_s1_on contents:nil attributes:nil];
    [self s1];
}

- (void)d1go:(NSString *)path {
    NSError *error;
    NSData *data = [NSData dataWithContentsOfFile:path];
    id plistFile = [NSPropertyListSerialization propertyListWithData:data options:0 format:NULL error:&error];
    NSData *asXML = [NSPropertyListSerialization dataWithPropertyList:plistFile format:NSPropertyListXMLFormat_v1_0 options:0 error:&error];
    if (error) {
        bigFullscreenBoiTitle = @"Error";
        bigFullscreenBoiText = nil;
        [self calert];
        return;
    }
    NSArray *strr = [[[NSString alloc] initWithData:asXML encoding:NSUTF8StringEncoding] componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *str = [[strr componentsJoinedByString:@""] stringByReplacingOccurrencesOfString:@"<string>com.apple.control-center.ConnectivityModule</string><string>com.apple.mediaremote.controlcenter.nowplaying</string><string>com.apple.control-center.OrientationLockModule</string><string>com.apple.control-center.DoNotDisturbModule</string><string>com.apple.control-center.DisplayModule</string><string>com.apple.control-center.AudioModule</string><string>com.apple.mediaremote.controlcenter.airplaymirroring</string>" withString:@""];
    str = [str stringByReplacingOccurrencesOfString:@"<key>fixed</key><array/>" withString:@"<key>fixed</key><array><string>com.apple.control-center.ConnectivityModule</string><string>com.apple.mediaremote.controlcenter.nowplaying</string><string>com.apple.control-center.OrientationLockModule</string><string>com.apple.control-center.DoNotDisturbModule</string><string>com.apple.control-center.DisplayModule</string><string>com.apple.control-center.AudioModule</string><string>com.apple.mediaremote.controlcenter.airplaymirroring</string></array>"];
    str = [str stringByReplacingOccurrencesOfString:@"<?xmlversion=\"1.0\"encoding=\"UTF-8\"?><!DOCTYPEplistPUBLIC\"-//Apple//DTDPLIST1.0//EN\"\"http://www.apple.com/DTDs/PropertyList-1.0.dtd\"><plistversion=\"1.0\">" withString:@"<?xml version=\"1.0\" encoding=\"UTF-8\"?><!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\"><plist version=\"1.0\">"];
    [str writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
    NSData *_data = [NSData dataWithContentsOfFile:@"/private/var/mobile/Library/ControlCenter/ModuleConfiguration.plist"];
    id _plistFile = [NSPropertyListSerialization propertyListWithData:_data options:0 format:NULL error:&error];
    NSData *_asXML = [NSPropertyListSerialization dataWithPropertyList:_plistFile format:NSPropertyListXMLFormat_v1_0 options:0 error:&error];
    if (error) {
        bigFullscreenBoiTitle = @"Error";
        bigFullscreenBoiText = nil;
        [self calert];
        return;
    }
    NSArray *_strr = [[[NSString alloc] initWithData:_asXML encoding:NSUTF8StringEncoding] componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *_str = [_strr componentsJoinedByString:@""];
    NSString *compare = [_strr componentsJoinedByString:@""];
    if ([_str containsString:@"<string>com.apple.control-center.ConnectivityModule</string>"]) {
        _str = [_str stringByReplacingOccurrencesOfString:@"<string>com.apple.control-center.ConnectivityModule</string>" withString:@""];
    } if ([_str containsString:@"<string>com.apple.mediaremote.controlcenter.nowplaying</string>"]) {
        _str = [_str stringByReplacingOccurrencesOfString:@"<string>com.apple.mediaremote.controlcenter.nowplaying</string>" withString:@""];
    } if ([_str containsString:@"<string>com.apple.control-center.OrientationLockModule</string>"]) {
        _str = [_str stringByReplacingOccurrencesOfString:@"<string>com.apple.control-center.OrientationLockModule</string>" withString:@""];
    } if ([_str containsString:@"<string>com.apple.control-center.DoNotDisturbModule</string>"]) {
        _str = [_str stringByReplacingOccurrencesOfString:@"<string>com.apple.control-center.DoNotDisturbModule</string>" withString:@""];
    } if ([_str containsString:@"<string>com.apple.control-center.DisplayModule</string>"]) {
        _str = [_str stringByReplacingOccurrencesOfString:@"<string>com.apple.control-center.DisplayModule</string>" withString:@""];
    } if ([_str containsString:@"<string>com.apple.control-center.AudioModule</string>"]) {
        _str = [_str stringByReplacingOccurrencesOfString:@"<string>com.apple.control-center.AudioModule</string>" withString:@""];
    } if ([_str containsString:@"<string>com.apple.mediaremote.controlcenter.airplaymirroring</string>"]) {
        _str = [_str stringByReplacingOccurrencesOfString:@"<string>com.apple.mediaremote.controlcenter.airplaymirroring</string>" withString:@""];
    } if (![_str isEqual: compare]) {
        _str = [_str stringByReplacingOccurrencesOfString:@"<?xmlversion=\"1.0\"encoding=\"UTF-8\"?><!DOCTYPEplistPUBLIC\"-//Apple//DTDPLIST1.0//EN\"\"http://www.apple.com/DTDs/PropertyList-1.0.dtd\"><plistversion=\"1.0\">" withString:@"<?xml version=\"1.0\" encoding=\"UTF-8\"?><!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\"><plist version=\"1.0\">"];
        [_str writeToFile:@"/private/var/mobile/Library/ControlCenter/ModuleConfiguration.plist" atomically:YES encoding:NSUTF8StringEncoding error:nil];
    }
    unlink(cc_s1_on_char);
    bigFullscreenBoiTitle = @"Success";
    bigFullscreenBoiText = @"Please respring your device.";
    [self calert];
    [self s1];
}

- (void)e2go:(NSString *)path {
    NSString *str = [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"UTF-8\"?><!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\"><plist version=\"1.0\"><dict><key>com.apple.Home.ControlCenter</key><dict><key>size</key><dict><key>height</key><integer>1</integer><key>width</key><integer>1</integer></dict></dict><key>com.apple.control-center.AudioModule</key><dict><key>size</key><dict><key>height</key><integer>%i</integer><key>width</key><integer>1</integer></dict></dict><key>com.apple.control-center.ConnectivityModule</key><dict><key>size</key><dict><key>height</key><integer>2</integer><key>width</key><integer>2</integer></dict></dict><key>com.apple.control-center.DisplayModule</key><dict><key>size</key><dict><key>height</key><integer>%i</integer><key>width</key><integer>1</integer></dict></dict><key>com.apple.mediaremote.controlcenter.airplaymirroring</key><dict><key>size</key><dict><key>width</key><integer>2</integer></dict></dict><key>com.apple.mediaremote.controlcenter.nowplaying</key><dict><key>size</key><dict><key>height</key><integer>2</integer><key>width</key><integer>2</integer></dict></dict></dict></plist>", (int)_audio.value, (int)_brightness.value];
    [str writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
    bigFullscreenBoiTitle = @"Success";
    bigFullscreenBoiText = @"Please respring your device.";
    [self calert];
}

- (IBAction)e1:(id)sender {
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~iphone.plist"]) {
        [self e1go:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~iphone.plist"];
    } else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~ipad.plist"]) {
        [self e1go:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~ipad.plist"];
    } else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~ipod.plist"]) {
        [self e1go:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~ipod.plist"];
    } else {
        bigFullscreenBoiTitle = @"Error";
        bigFullscreenBoiText = nil;
        [self calert];
    }
}

- (IBAction)d1:(id)sender {
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~iphone.plist"]) {
        [self d1go:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~iphone.plist"];
    } else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~ipad.plist"]) {
        [self d1go:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~ipad.plist"];
    } else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~ipod.plist"]) {
        [self d1go:@"/System/Library/PrivateFrameworks/ControlCenterServices.framework/DefaultModuleOrder~ipod.plist"];
    } else {
        bigFullscreenBoiTitle = @"Error";
        bigFullscreenBoiText = nil;
        [self calert];
    }
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (void)s1 {
    if ([[NSFileManager defaultManager] fileExistsAtPath:cc_s1_on]) {
        [_e1btn setEnabled:NO];
        [_d1btn setEnabled:YES];
        [UIView animateWithDuration:0.5f animations:^{
            [_e1btn setBackgroundColor:hex(0xB8B8B8, 1.0)]; [_d1btn setBackgroundColor:hex(0xFF0033, 1.0)];
        }];
    } else {
        [_e1btn setEnabled:YES];
        [_d1btn setEnabled:NO];
        [UIView animateWithDuration:0.5f animations:^{
            [_e1btn setBackgroundColor:hex(0x007AFF, 1.0)]; [_d1btn setBackgroundColor:hex(0xB8B8B8, 1.0)];
        }];
    }
}

- (IBAction)e2:(id)sender {
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterUI.framework/DefaultModuleSettings~iphone.plist"]) {
        [self e2go:@"/System/Library/PrivateFrameworks/ControlCenterUI.framework/DefaultModuleSettings~iphone.plist"];
    } else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterUI.framework/DefaultModuleSettings~ipad.plist"]) {
        [self e2go:@"/System/Library/PrivateFrameworks/ControlCenterUI.framework/DefaultModuleSettings~ipad.plist"];
    } else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/PrivateFrameworks/ControlCenterUI.framework/DefaultModuleSettings~ipod.plist"]) {
        [self e2go:@"/System/Library/PrivateFrameworks/ControlCenterUI.framework/DefaultModuleSettings~ipod.plist"];
    } else {
        bigFullscreenBoiTitle = @"Error";
        bigFullscreenBoiText = nil;
        [self calert];
    }
}

- (void)updateValTexts {
    [_audioVal setText:[NSString stringWithFormat:@"%i", (int)_audio.value]];
     [_brightnessVal setText:[NSString stringWithFormat:@"%i", (int)_brightness.value]];
}

- (void)visualStyle {
    [self.navigationController.navigationBar setValue:@(YES) forKeyPath:@"hidesShadow"];
    if (darkModeIsEnabled()) {
        _customisationText.textColor = [UIColor lightTextColor];
        _cusomisationDescription.textColor = [UIColor lightTextColor];
        _audioModuleText.textColor = [UIColor lightTextColor];
        _brightnessModuleText.textColor = [UIColor lightTextColor];
        _audioVal.textColor = [UIColor lightTextColor];
        _brightnessVal.textColor = [UIColor lightTextColor];
        [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
        [self.view setBackgroundColor:hex(0x151E29, 1.0)];
        [self.navigationController.navigationBar setBarTintColor:hex(0x1B2737, 1.0)];
    } else {
        _customisationText.textColor = [UIColor darkTextColor];
        _cusomisationDescription.textColor = [UIColor darkTextColor];
        _audioModuleText.textColor = [UIColor darkTextColor];
        _brightnessModuleText.textColor = [UIColor darkTextColor];
        _audioVal.textColor = [UIColor darkTextColor];
        _brightnessVal.textColor = [UIColor darkTextColor];
        [self.navigationController.navigationBar setBarStyle:UIBarStyleDefault];
        [self.navigationController.navigationBar setBarTintColor:hex(0xF2F2F2, 1.0)];
        [self.view setBackgroundColor:hex(0xFAFAFA, 1.0)];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    if (!remounted()) {
        cc_s1_on = @"/private/var/mobile/cc_s1_on";
        cc_s1_on_char = "/private/var/mobile/cc_s1_on";
    } else {
        cc_s1_on = @"/.cc_s1_on";
        cc_s1_on_char = "/.cc_s1_on";
    }
    [self applyBtn:_e1btn];
    [self applyBtn:_d1btn];
    [self applyBtn:_e2btn];
    if ([[NSFileManager defaultManager] fileExistsAtPath:cc_s1_on]) {
        [_e1btn setEnabled:NO];
        [_d1btn setEnabled:YES];
        [_e1btn setBackgroundColor:hex(0xB8B8B8, 1.0)];
        [_d1btn setBackgroundColor:hex(0xFF0033, 1.0)];
    } else {
        [_e1btn setEnabled:YES];
        [_d1btn setEnabled:NO];
        [_e1btn setBackgroundColor:hex(0x007AFF, 1.0)];
        [_d1btn setBackgroundColor:hex(0xB8B8B8, 1.0)];
    }
    [NSTimer scheduledTimerWithTimeInterval:0.1f target:self selector:@selector(updateValTexts) userInfo:nil repeats:YES];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(visualStyle)     name:@"updatedVisualStyle" object:nil];
    [self visualStyle];
}

- (void)viewDidLayoutSubviews {
    if (UI_USER_INTERFACE_IDIOM() != UIUserInterfaceIdiomPad) {
        self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width, _cusomisationDescription.frame.size.height + _e1btn.frame.size.height + _d1btn.frame.size.height + _e2btn.frame.size.height + ((_audioModuleText.frame.size.height + _audio.frame.size.height + _audioVal.frame.size.height)*2) + 10);
        //struct utsname u;
        //uname(&u);
        //NSLog(@"%@", [NSString stringWithUTF8String:u.machine]);
        //if (strcmp(u.machine, "iPhone6,1") == 0 || strcmp(u.machine, "iPhone6,2") == 0 || strcmp(u.machine, "iPhone8,4") == 0 || strcmp(u.machine, "iPod7,1") == 0) {
        //  self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 175);
        //} else if (strcmp(u.machine, "iPhone7,2") == 0 || strcmp(u.machine, "iPhone8,1") == 0) {
        //    self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 40);
        //}
    }
}

@end

@interface Masks ()
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *alertTitle;
@property (strong, nonatomic) IBOutlet UITextView *alertText;
@property (strong, nonatomic) IBOutlet UIButton *dismissAlertBtn;
@property (strong, nonatomic) IBOutlet UITextField *custommaskurl;
@property (strong, nonatomic) IBOutlet UIView *urlalert;
@property (strong, nonatomic) IBOutlet UIView *wait;
@property (strong, nonatomic) IBOutlet UIButton *respringBtn;

@end

@implementation Masks

- (IBAction)respringAction:(id)sender {
    respringDevice();
}

- (void)waitK {
    if ([stringWithContentsOfLocalFile(@"showLoader") isEqual: @"yes"]) {
        [_wait setHidden:NO];
        [_wait setAlpha:0.0f];
        [UIView animateWithDuration:0.5f animations:^{
            [_wait setAlpha:1.0f]; [_X setAlpha:1.0f];
        }];
    }
}

- (void)doneWaiting {
    if ([stringWithContentsOfLocalFile(@"showLoader") isEqual: @"yes"]) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
            [_wait setAlpha:1.0f];
            [UIView animateWithDuration:0.5f animations:^{
                [_wait setAlpha:0.0f]; [_X setAlpha:0.0f];
            } completion:^(BOOL finished) {
                [_wait setHidden:YES];
            }];
        });});
    }
}

- (void)calert:(NSString*)alertTitle alertMessage:(NSString*)alertMessage dismissButton:(NSString*)dismissButton buttonVis:(int)buttonVis dismissBtnAction:(SEL)dismissBtnAction {
    [_dismissAlertBtn setExclusiveTouch:YES];
    [_cancel setEnabled:NO];
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alertTitle setText:alertTitle];
    [_alertText setText:alertMessage];
    if (buttonVis == 0) {
        [_dismissAlertBtn setHidden:YES];
    } else if (buttonVis == 1) {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:@selector(calertd) forControlEvents:UIControlEventTouchUpInside];
    } else {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:dismissBtnAction forControlEvents:UIControlEventTouchUpInside];
    }
    [_alert setHidden:NO]; [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)calertd {
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    } completion:^(BOOL finished) {
        [_respringBtn setHidden:YES];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];});});
    [_cancel setEnabled:YES];
}

- (IBAction)xBtnPressed:(id)sender {
    [self calertd];
}

- (NSString *)getFE:(NSURL *)url{
    NSString *urlString = [url absoluteString];
    NSArray *componentsArray = [urlString componentsSeparatedByString:@"."];
    NSString *fileExtension = [componentsArray lastObject];
    return fileExtension;
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (void)checkWiFiC {
    if (noWiFi) {
        [UIView animateWithDuration:0.5f animations:^{
            [_custom bgDisabledColour];
        }];
        [_custom setEnabled:NO];
    } else {
        [UIView animateWithDuration:0.5f animations:^{
            [_custom bgBlueColour];
        }];
        [_custom setEnabled:YES];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [self applyBtn:_custom];
    [self applyBtn:_change];
    [self applyBtn:_cancel];
    [_respringBtn setHidden:YES];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(checkWiFiC) userInfo:nil repeats:YES];
}

- (IBAction)cancel:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)applyMask:(NSString *)zipName {
    [SSZipArchive unzipFileAtPath:[[NSBundle mainBundle] pathForResource:zipName ofType:@"zip"] toDestination:@"/private/var/mobile/Documents/Torngat_TMP_Mask_DIR/"];
    [self moveFiles];
    [[NSFileManager defaultManager] removeItemAtPath:@"/private/var/mobile/Documents/Torngat_TMP_Mask_DIR/" error:nil];    [[NSFileManager defaultManager] removeItemAtPath:@"/private/var/containers/Shared/SystemGroup/systemgroup.com.apple.lsd.iconscache/Library/Caches/com.apple.IconsCache/" error:nil];
    [[NSFileManager defaultManager] createDirectoryAtPath:@"/private/var/containers/Shared/SystemGroup/systemgroup.com.apple.lsd.iconscache/Library/Caches/com.apple.IconsCache/" withIntermediateDirectories:false attributes:nil error:nil];
    if (dontRespring == FALSE){[_respringBtn setHidden:NO];}
    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
}

- (IBAction)change:(id)sender {
    NSInteger selectedSegment = _o.selectedSegmentIndex;
    if (selectedSegment == 0) {
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            [self applyMask:@"iPadDefault"];
        } else {
            [self applyMask:@"iPhoneDefault"];
        }
    } else if (selectedSegment == 1) {
        [self applyMask:@"Circle"];
    } else if (selectedSegment == 2) {
        [self applyMask:@"Leaf"];
    } else if (selectedSegment == 3) {
        [self applyMask:@"Tag"];
    } else {
        [self calert:@"Failed" alertMessage:@"Please select a mask." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
    }
}

- (void)moveFiles {
    BOOL isDir;
    NSString *oPath = @"/private/var/mobile/Documents/Torngat_TMP_Mask_DIR/";
    [[NSFileManager defaultManager] fileExistsAtPath:oPath isDirectory:&isDir];
    if(isDir) {
        NSArray *contentOfDirectory = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:oPath error:NULL];
        int contentcount = (int)[contentOfDirectory count];
        int i;
        for(i = 0; i < contentcount; i++) {
            NSString *fileName = [[contentOfDirectory objectAtIndex:i] stringByReplacingOccurrencesOfString:@"/" withString:@""];
            NSString *origPath = [NSString stringWithFormat:@"%@%@", oPath, fileName];
            if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/System/Library/PrivateFrameworks/MobileIcons.framework/%@", fileName] isDirectory:nil]) {
                [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"/System/Library/PrivateFrameworks/MobileIcons.framework/%@", fileName] error:nil];
                [[NSFileManager defaultManager] copyItemAtPath:origPath toPath:[NSString stringWithFormat:@"/System/Library/PrivateFrameworks/MobileIcons.framework/%@", fileName] error:nil];
            }
        }
    }
}

- (IBAction)continueCustom:(id)sender {
    [_urlalert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [self.view endEditing:YES];
    [_cancel setEnabled:NO];
    [_custom setEnabled:NO];
    [_change setEnabled:NO];
    [_o setEnabled:NO];
    [UIView animateWithDuration:0.5f animations:^{
        [_urlalert setAlpha:0.0f]; [_X setAlpha:0.0f];
    } completion:^(BOOL finished){[self.view endEditing:YES];_custommaskurl.text = @"";[self.view endEditing:YES];}];
    NSURL *url = [NSURL URLWithString:_custommaskurl.text];
    NSUInteger length = [_custommaskurl.text length];
    if (length == 0) {
        [self calert:@"Failed" alertMessage:@"No URL was supplied." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
        [_cancel setEnabled:YES];
        [_custom setEnabled:YES];
        [_change setEnabled:YES];
        [_o setEnabled:YES];
        return;
    } else {
        [self waitK];
    }
    NSLog(@"URL: ==>%@<==", url);
    //if (length != 0) {
        if ([[[self getFE:url] lowercaseString] isEqual: @"zip"] || [[[self getFE:url] lowercaseString] isEqual: @"tgm"] || [[[self getFE:url] lowercaseString] isEqual: @"mask"]) {
            NSData *urlData = [NSData dataWithContentsOfURL:url];
            if (urlData) {
                [urlData writeToFile:@"/private/var/mobile/Documents/Torngat_TMP_Mask_Files.zip" atomically:YES];
                [[NSFileManager defaultManager] createDirectoryAtPath:@"/private/var/mobile/Documents/Torngat_TMP_Mask_DIR/" withIntermediateDirectories:NO attributes:nil error:nil];
                [SSZipArchive unzipFileAtPath:@"/private/var/mobile/Documents/Torngat_TMP_Mask_Files.zip" toDestination:@"/private/var/mobile/Documents/Torngat_TMP_Mask_DIR/"];
                [[NSFileManager defaultManager] removeItemAtPath:@"/private/var/mobile/Documents/Torngat_TMP_Mask_Files.zip" error:nil];
                [self moveFiles];
                [[NSFileManager defaultManager] removeItemAtPath:@"/private/var/mobile/Documents/Torngat_TMP_Mask_DIR/" error:nil];
                [[NSFileManager defaultManager] removeItemAtPath:@"/var/containers/Shared/SystemGroup/systemgroup.com.apple.lsd.iconscache/Library/Caches/com.apple.IconsCache/" error:nil];
                [[NSFileManager defaultManager] createDirectoryAtPath:@"/var/containers/Shared/SystemGroup/systemgroup.com.apple.lsd.iconscache/Library/Caches/com.apple.IconsCache/" withIntermediateDirectories:false attributes:nil error:nil];
                if (dontRespring == FALSE){[_respringBtn setHidden:NO];}
                [self doneWaiting];
                [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                [_cancel setEnabled:YES];
                [_custom setEnabled:YES];
                [_change setEnabled:YES];
                [_o setEnabled:YES];
            } else {
                [self doneWaiting];
                [self calert:@"Failed" alertMessage:@"No data was received." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
                [_cancel setEnabled:YES];
                [_custom setEnabled:YES];
                [_change setEnabled:YES];
                [_o setEnabled:YES];
            }
        } else {
            [self calert:@"Failed" alertMessage:@"Unsupported file format." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
            [_cancel setEnabled:YES];
            [_custom setEnabled:YES];
            [_change setEnabled:YES];
            [_o setEnabled:YES];
        }/*} else {
            [self calert:@"Failed" alertMessage:@"No URL was supplied." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
            [_cancel setEnabled:YES];
            [_custom setEnabled:YES];
            [_change setEnabled:YES];
            [_o setEnabled:YES];
        }*/
    [self.view endEditing:YES];
}

- (IBAction)custom:(id)sender {
    [_urlalert setAlpha:0.0];
    [_X setAlpha:0.0];
    [_urlalert setHidden:NO];
    [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_urlalert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (IBAction)closeURLAlert:(id)sender {
    [self.view endEditing:YES];
    [_urlalert setAlpha:1.0f];
    [UIView animateWithDuration:0.7f animations:^{
        [_urlalert setAlpha:0.0f];
    } completion:^(BOOL finished){[self.view endEditing:YES];_custommaskurl.text = @"";[self.view endEditing:YES];}];
}

@end

@interface bootlogo ()
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *alertTitle;
@property (strong, nonatomic) IBOutlet UITextView *alertText;
@property (strong, nonatomic) IBOutlet UIButton *dismissAlertBtn;
@property (strong, nonatomic) IBOutlet UIView *wait;

@end

@implementation bootlogo

- (void)waitK {
    if ([stringWithContentsOfLocalFile(@"showLoader") isEqual: @"yes"]) {
        [_wait setHidden:NO];
        [_wait setAlpha:0.0f];
        [UIView animateWithDuration:0.5f animations:^{
            [_wait setAlpha:1.0f]; [_X setAlpha:1.0f];
        }];
    }
}

- (void)doneWaiting {
    if ([stringWithContentsOfLocalFile(@"showLoader") isEqual: @"yes"]) {
        [_wait setAlpha:1.0f];
        [UIView animateWithDuration:0.5f animations:^{
            [_wait setAlpha:0.0f]; [_X setAlpha:0.0f];
        } completion:^(BOOL finished) {
            [_wait setHidden:YES];
        }];
    }
}

- (void)calert:(NSString*)alertTitle alertMessage:(NSString*)alertMessage dismissButton:(NSString*)dismissButton buttonVis:(int)buttonVis dismissBtnAction:(SEL)dismissBtnAction {
    [_dismissAlertBtn setExclusiveTouch:YES];
    [_cancel setEnabled:NO];
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alertTitle setText:alertTitle];
    [_alertText setText:alertMessage];
    if (buttonVis == 0) {
        [_dismissAlertBtn setHidden:YES];
    } else if (buttonVis == 1) {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:@selector(calertd) forControlEvents:UIControlEventTouchUpInside];
    } else {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:dismissBtnAction forControlEvents:UIControlEventTouchUpInside];
    }
    [_alert setHidden:NO]; [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)calertd {
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];});});
    [_cancel setEnabled:YES];
}

- (IBAction)xBtnPressed:(id)sender {
    [self calertd];
}

- (NSString *)getFE:(NSURL *)url{
    NSString *urlString = [url absoluteString];
    NSArray *componentsArray = [urlString componentsSeparatedByString:@"."];
    NSString *fileExtension = [componentsArray lastObject];
    return fileExtension;
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (void)revertBtn {
    [_revert setEnabled:YES];
    [_revert setBackgroundColor:hex(0x007AFF, 1.0)];
}

- (void)checkWiFiC {
    if (noWiFi) {
        [UIView animateWithDuration:0.5f animations:^{
            [_change bgDisabledColour];
        }];
        [_change setEnabled:NO];
    } else {
        [UIView animateWithDuration:0.5f animations:^{
            [_change bgBlueColour];
        }];
        [_change setEnabled:YES];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [self applyBtn:_revert];
    [self applyBtn:_change];
    [self applyBtn:_cancel];
    [self revertBtn];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(checkWiFiC) userInfo:nil repeats:YES];
}

- (IBAction)cancel:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (BOOL)writeBootlogo:(NSData*)urlData {
    BOOL BOOLEAN_RET = FALSE;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo@2x~ipad.png" atomically:YES];
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo-black@2x~ipad.png" atomically:YES];
        //[urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo@3x~ipad.png" atomically:YES];
        //[urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo-black@3x~ipad.png" atomically:YES];
        BOOLEAN_RET = TRUE;
    } else {
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo@2x~iphone.png" atomically:YES];
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo-black@2x~iphone.png" atomically:YES];
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo@3x~iphone.png" atomically:YES];
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo-black@3x~iphone.png" atomically:YES];
        BOOLEAN_RET = TRUE;
    }
    [self doneWaiting];
    [self calert:@"Success" alertMessage:@"Your bootlogo was successfully changed." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
    [self revertBtn];
    return BOOLEAN_RET;
}

- (BOOL)writeBootlogoWithSize:(NSData*)urlData {
    BOOL BOOLEAN_RET = FALSE;
    NSLog(@"%ld", lround([UIScreen mainScreen].scale));
    UIImage *bootlogoToResize = [UIImage imageWithData:urlData];
    CGSize cgsize;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        if (lround([UIScreen mainScreen].scale) == 2) {
            cgsize = CGSizeMake(225.0, 278.0);
        } else if (lround([UIScreen mainScreen].scale) == 3) {
            cgsize = CGSizeMake(339.0, 417.0);
        } else {
            cgsize = CGSizeMake(113.0, 139.0);
        }
    } else {
        if (lround([UIScreen mainScreen].scale) == 2) {
            cgsize = CGSizeMake(129.0, 158.0);
        } else if (lround([UIScreen mainScreen].scale) == 3) {
            cgsize = CGSizeMake(194.0, 237.0);
        } else {
            cgsize = CGSizeMake(65.0, 79.0);
        }
    }
    UIGraphicsBeginImageContextWithOptions(cgsize, NO, 0.0);
    [bootlogoToResize drawInRect:CGRectMake(0, 0, cgsize.width, cgsize.height)];
    bootlogoToResize = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    urlData = UIImagePNGRepresentation(bootlogoToResize);
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo@2x~ipad.png" atomically:YES];
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo-black@2x~ipad.png" atomically:YES];
        //[urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo@3x~ipad.png" atomically:YES];
        //[urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo-black@3x~ipad.png" atomically:YES];
        BOOLEAN_RET = TRUE;
    } else {
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo@2x~iphone.png" atomically:YES];
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo-black@2x~iphone.png" atomically:YES];
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo@3x~iphone.png" atomically:YES];
        [urlData writeToFile:@"/System/Library/PrivateFrameworks/ProgressUI.framework/apple-logo-black@3x~iphone.png" atomically:YES];
        BOOLEAN_RET = TRUE;
    }
    return BOOLEAN_RET;
}

- (IBAction)change:(id)sender {
    [self waitK];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        if ([stringWithContentsOfLocalFile(@"showLoader") isEqual: @"yes"]) { [NSThread sleepForTimeInterval:0.5f]; }
        dispatch_async(dispatch_get_main_queue(), ^{
                NSURL *url = [NSURL URLWithString:_urlf.text];
                if (![_urlf.text isEqual: @""]) {
                    if ([[[self getFE:url] lowercaseString] isEqual: @"jpg"] || [[[self getFE:url] lowercaseString] isEqual: @"jpeg"] || [[[self getFE:url] lowercaseString] isEqual: @"png"] || [[[self getFE:url] lowercaseString] isEqual: @"ico"]) {
                        NSData *urlData = [NSData dataWithContentsOfURL:url];
                        if (urlData) {
                            if([stringWithContentsOfLocalFile(@"resizeBootlogos") isEqual: @"yes"]) {
                                [self writeBootlogoWithSize:urlData];
                                [self doneWaiting];
                                [self calert:@"Success" alertMessage:@"Your bootlogo was successfully changed." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                                [self revertBtn];
                            } else {
                                [self writeBootlogo:urlData];
                                [self doneWaiting];
                                [self calert:@"Success" alertMessage:@"Your bootlogo was successfully changed." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                                [self revertBtn];
                            }
                        } else {
                            [self doneWaiting];
                            [self calert:@"Failed" alertMessage:@"No data was received." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
                        }
                    } else {
                        [self doneWaiting];
                        [self calert:@"Failed" alertMessage:@"Unsupported file format." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
                    }
                } else {
                    [self doneWaiting];
                    [self calert:@"Failed" alertMessage:@"No URL was supplied." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
                }
        });
    });
}

- (IBAction)revert:(id)sender {
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        [SSZipArchive unzipFileAtPath:[[NSBundle mainBundle] pathForResource:@"iPadProgressUI" ofType:@"zip"] toDestination:@"/private/var/mobile/Documents/Torngat_TMP_ProgressUI_DIR/"];
    } else {
        [SSZipArchive unzipFileAtPath:[[NSBundle mainBundle] pathForResource:@"iPhoneProgressUI" ofType:@"zip"] toDestination:@"/private/var/mobile/Documents/Torngat_TMP_ProgressUI_DIR/"];
    }
    BOOL isDir;
    NSString *oPath = @"/private/var/mobile/Documents/Torngat_TMP_ProgressUI_DIR/";
    [[NSFileManager defaultManager] fileExistsAtPath:oPath isDirectory:&isDir];
    if(isDir) {
        NSArray *contentOfDirectory = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:oPath error:NULL];
        int contentcount = (int)[contentOfDirectory count];
        int i;
        for(i = 0; i < contentcount; i++) {
            NSString *fileName = [[contentOfDirectory objectAtIndex:i] stringByReplacingOccurrencesOfString:@"/" withString:@""];
            NSString *origPath = [NSString stringWithFormat:@"%@%@", oPath, fileName];
            if ([[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"/System/Library/PrivateFrameworks/ProgressUI.framework/%@", fileName] isDirectory:nil]) {
                [[NSFileManager defaultManager] removeItemAtPath:[NSString stringWithFormat:@"/System/Library/PrivateFrameworks/ProgressUI.framework/%@", fileName] error:nil];
                [[NSFileManager defaultManager] copyItemAtPath:origPath toPath:[NSString stringWithFormat:@"/System/Library/PrivateFrameworks/ProgressUI.framework/%@", fileName] error:nil];
            }
        }
    }
    [[NSFileManager defaultManager] removeItemAtPath:@"/private/var/mobile/Documents/Torngat_TMP_ProgressUI_DIR/" error:nil];
    [self calert:@"Success" alertMessage:@"Your bootlogo was successfully changed." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
}

- (IBAction)keybtn:(id)sender {
    [self.view endEditing:YES];
}

@end

@interface respringv ()
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *loader;

@end

@implementation respringv

- (void)viewWillAppear:(BOOL)animated {
    [_loader startAnimating];
}

- (void)actuallyDoIt {
    kill(backboardd(), SIGKILL);
    exit(0);
}

- (void)viewDidLayoutSubviews {
    [self performSelector:@selector(actuallyDoIt) withObject:nil afterDelay:0.8];
}

@end

@interface credits ()
@property (strong, nonatomic) IBOutlet UILabel *exploit;
@property (strong, nonatomic) IBOutlet UILabel *exploitDev;
@property (strong, nonatomic) IBOutlet UILabel *exploitFork;
@property (strong, nonatomic) IBOutlet UILabel *exploitForkDev;
@property (strong, nonatomic) IBOutlet UIImageView *exploitDevImg;
@property (strong, nonatomic) IBOutlet UIImageView *exploitForkDevImg;
@property (strong, nonatomic) IBOutlet UIImageView *me;
@property (strong, nonatomic) IBOutlet UIImageView *skitty;
@property (strong, nonatomic) IBOutlet UIImageView *b;
@property (strong, nonatomic) IBOutlet UIImageView *enterpriseCodeSignerIcon;
@property (strong, nonatomic) IBOutlet UIView *lol;
@property (strong, nonatomic) IBOutlet UIView *official;
@property (strong, nonatomic) IBOutlet UILabel *codesignerName;
@property (strong, nonatomic) IBOutlet UIView *seven;
@property (strong, nonatomic) IBOutlet UILabel *officialURL;

@end

@implementation credits

- (void)modid:(UIView*)identifier {
    //if (darkModeIsEnabled()) {
        
    //} else {
        identifier.backgroundColor = hex(0xEBEBF1, 1.0);
    //}
    identifier.layer.cornerRadius = 10.0f;
    identifier.layer.borderColor = hex(0xEBEBF1, 1.0).CGColor;
    identifier.layer.borderWidth = 0.5f;
}

- (void)visualStyle {
    [self.navigationController.navigationBar setValue:@(YES) forKeyPath:@"hidesShadow"];
    if (darkModeIsEnabled()) {
        [_scroll setIndicatorStyle:UIScrollViewIndicatorStyleWhite];
        [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
        [self.navigationController.navigationBar setBarTintColor:hex(0x1B2737, 1.0)];
        [self.view setBackgroundColor:hex(0x151E29, 1.0)];
        [_official setBackgroundColor:hex(0x151E29, 1.0)];
        [_officialURL setTextColor:[UIColor whiteColor]];
    } else {
        [_scroll setIndicatorStyle:UIScrollViewIndicatorStyleBlack];
        [self.navigationController.navigationBar setBarStyle:UIBarStyleDefault];
        [self.navigationController.navigationBar setBarTintColor:hex(0xF2F2F2, 1.0)];
        [self.view setBackgroundColor:hex(0xFAFAFA, 1.0)];
        [_official setBackgroundColor:hex(0xFAFAFA, 1.0)];
        [_officialURL setTextColor:[UIColor blackColor]];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [self modid:_one];
    [self modid:_two];
    [self modid:_three];
    [self modid:_four];
    [self modid:_five];
    [self modid:_six];
    if (![codesigner isEqual: @"Your username / alias"]) {
        [self modid:_seven];
    } else {
        _seven.layer.cornerRadius = 10.0f;
    }
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(visualStyle)     name:@"updatedVisualStyle" object:nil];
    [self visualStyle];
}

NSData *imageData;

BOOL WiFi;

NSString *exploitDevIconURL = @"";
NSString *exploitForkDevIconURL = @"";
NSString *exploitDev = @"";
NSString *exploitForkDev = @"";
NSString *exploit = @"";
NSString *exploitFork = @"";
NSTimer *timer;

- (void)checkWiFiC {
    if (WiFi == YES) {
        return;
    } else {
        if (noWiFi) {
            return;
        } else {
            if (noWiFi) {
                return;
            } else {
                dispatch_async(dispatch_get_global_queue(0,0), ^{
                    imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:exploitDevIconURL]];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        _exploitDevImg.image = [UIImage imageWithData:imageData];
                        dispatch_async(dispatch_get_global_queue(0,0), ^{
                            imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:exploitForkDevIconURL]];
                            dispatch_async(dispatch_get_main_queue(), ^{
                                _exploitForkDevImg.image = [UIImage imageWithData:imageData];
                                dispatch_async(dispatch_get_global_queue(0,0), ^{
                                    imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:@"https://twitter.com/1GamerDev/profile_image?size=original"]];
                                    dispatch_async(dispatch_get_main_queue(), ^{
                                        _me.image = [UIImage imageWithData:imageData];
                                        dispatch_async(dispatch_get_global_queue(0,0), ^{
                                            imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: @"https://twitter.com/Skittyblock/profile_image?size=original"]];
                                            dispatch_async(dispatch_get_main_queue(), ^{
                                                _skitty.image = [UIImage imageWithData:imageData];
                                                dispatch_async(dispatch_get_global_queue(0,0), ^{
                                                    imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: @"https://twitter.com/B1n4r1b01/profile_image?size=original"]];
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        _b.image = [UIImage imageWithData:imageData];
                                                        dispatch_async(dispatch_get_main_queue(), ^{
                                                            _b.image = [UIImage imageWithData:imageData];
                                                            dispatch_async(dispatch_get_global_queue(0,0), ^{
                                                                imageData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:@"https://maxcdn.icons8.com/Share/icon/color/Logos/icons8_logo1600.png"]];
                                                                dispatch_async(dispatch_get_main_queue(), ^{
                                                                    _icons8.image = [UIImage imageWithData:imageData];
                                                                    dispatch_async(dispatch_get_global_queue(0,0), ^{
                                                                        if (![codesigner isEqual: @"Your username / alias"]) {
                                                                            imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: codesignerIcon]];
                                                                            dispatch_async(dispatch_get_main_queue(), ^{
                                                                                _enterpriseCodeSignerIcon.image = [UIImage imageWithData:imageData];
                                                                                imageData = NULL;
                                                                            });
                                                                        } else {
                                                                            dispatch_async(dispatch_get_main_queue(), ^{
                                                                                imageData = NULL;
                                                                            });
                                                                        }
                                                                        [timer invalidate];
                                                                        timer = nil;
                                                                    });
                                                                });
                                                            });
                                                        });
                                                    });
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            }}
    }
}

- (void)roundCredits {
    _one.layer.masksToBounds = YES;
    _two.layer.masksToBounds = YES;
    _three.layer.masksToBounds = YES;
    _four.layer.masksToBounds = YES;
    _five.layer.masksToBounds = YES;
    _six.layer.masksToBounds = YES;
    _seven.layer.masksToBounds = YES;
    _one.clipsToBounds = YES;
    _two.clipsToBounds = YES;
    _three.clipsToBounds = YES;
    _four.clipsToBounds = YES;
    _five.clipsToBounds = YES;
    _six.clipsToBounds = YES;
    _seven.clipsToBounds = YES;
}

- (void)viewDidLoad {
    if ([usedExploit isEqual:@"multi_path"]) {
        exploitForkDevIconURL = @"https://twitter.com/Morpheus______/profile_image?size=original";
        exploitDevIconURL = @"https://twitter.com/i41nbeer/profile_image?size=original";
        exploitDev = @"i41nbeer";
        exploitForkDev = @"Morpheus______";
        exploit = @"multi_path";
        exploitFork = @"QiLin";
    }
    [_exploitDev setText:exploitDev];
    [_exploitForkDev setText:exploitForkDev];
    [_exploit setText:exploit];
    [_exploitFork setText:exploitFork];
    if (![codesigner isEqual: @"Your username / alias"]) {
        [_codesignerName setText:codesigner];
        [_official setHidden:YES];
    }
    if (noWiFi) {
        _exploitDevImg.image = [UIImage imageNamed:@"q.png"];
        _exploitForkDevImg.image = [UIImage imageNamed:@"q.png"];
        _me.image = [UIImage imageNamed:@"q.png"];
        _skitty.image = [UIImage imageNamed:@"q.png"];
        _b.image = [UIImage imageNamed:@"q.png"];
        _enterpriseCodeSignerIcon.image = [UIImage imageNamed:@"q.png"];
        _icons8.image = [UIImage imageNamed:@"q.png"];
        WiFi = NO;
        [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(checkWiFiC) userInfo:nil repeats:YES];
    } else {
        dispatch_async(dispatch_get_global_queue(0,0), ^{
            imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:exploitDevIconURL]];
            dispatch_async(dispatch_get_main_queue(), ^{
                _exploitDevImg.image = [UIImage imageWithData:imageData];
                dispatch_async(dispatch_get_global_queue(0,0), ^{
                    imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:exploitForkDevIconURL]];
                    dispatch_async(dispatch_get_main_queue(), ^{
                        _exploitForkDevImg.image = [UIImage imageWithData:imageData];
                        dispatch_async(dispatch_get_global_queue(0,0), ^{
                            imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: @"https://twitter.com/1GamerDev/profile_image?size=original"]];
                            dispatch_async(dispatch_get_main_queue(), ^{
                                _me.image = [UIImage imageWithData:imageData];
                                dispatch_async(dispatch_get_global_queue(0,0), ^{
                                    imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: @"https://twitter.com/Skittyblock/profile_image?size=original"]];
                                    dispatch_async(dispatch_get_main_queue(), ^{
                                        _skitty.image = [UIImage imageWithData:imageData];
                                        dispatch_async(dispatch_get_global_queue(0,0), ^{
                                            imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: @"https://twitter.com/B1n4r1b01/profile_image?size=original"]];
                                            dispatch_async(dispatch_get_main_queue(), ^{
                                                _b.image = [UIImage imageWithData:imageData];
                                                dispatch_async(dispatch_get_main_queue(), ^{
                                                    _b.image = [UIImage imageWithData:imageData];
                                                    dispatch_async(dispatch_get_global_queue(0,0), ^{
                                                        imageData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:@"https://maxcdn.icons8.com/Share/icon/color/Logos/icons8_logo1600.png"]];
                                                        dispatch_async(dispatch_get_main_queue(), ^{
                                                            _icons8.image = [UIImage imageWithData:imageData];
                                                            dispatch_async(dispatch_get_global_queue(0,0), ^{
                                                                if (![codesigner isEqual: @"Your username / alias"]) {
                                                                    imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: codesignerIcon]];
                                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                                        _enterpriseCodeSignerIcon.image = [UIImage imageWithData:imageData];
                                                                        imageData = NULL;
                                                                    });
                                                                } else {
                                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                                        imageData = NULL;
                                                                    });
                                                                }
                                                            });
                                                        });
                                                    });
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    }
    timer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(roundCredits) userInfo:nil repeats:YES];
    [timer fire];
}

- (void)viewDidLayoutSubviews {
    self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width, (_one.frame.size.height*7) + 65);
    /*struct utsname u;
    uname(&u);
    if (strcmp(u.machine, "iPhone6,1") == 0 || strcmp(u.machine, "iPhone6,2") == 0 || strcmp(u.machine, "iPhone8,4") == 0 || strcmp(u.machine, "iPod7,1") == 0) {
        self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 320);
    } else if (strcmp(u.machine, "iPhone7,2") == 0 || strcmp(u.machine, "iPhone8,1") == 0) {
        self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 210);
    } else {
        if (UI_USER_INTERFACE_IDIOM() != UIUserInterfaceIdiomPad) {
            self.scroll.contentSize = CGSizeMake(self.scroll.frame.size.width,  self.scroll.frame.size.height + 170);
        }
    }*/
}

@end

@interface fonts ()
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *alertTitle;
@property (strong, nonatomic) IBOutlet UITextView *alertText;
@property (strong, nonatomic) IBOutlet UIButton *dismissAlertBtn;
@property (strong, nonatomic) IBOutlet UITextField *urlf;
@property (strong, nonatomic) IBOutlet UIButton *change;
@property (strong, nonatomic) IBOutlet UISegmentedControl *o;
@property (strong, nonatomic) IBOutlet UIButton *cancel;
@property (strong, nonatomic) IBOutlet UIView *wait;
@property (strong, nonatomic) IBOutlet UIButton *respringBtn;
@property (strong, nonatomic) IBOutlet UIButton *revertBtn;

@end

@implementation fonts

- (void)waitK {
    if ([stringWithContentsOfLocalFile(@"showLoader") isEqual: @"yes"]) {
        [_wait setHidden:NO];
        [_wait setAlpha:0.0f];
        [UIView animateWithDuration:0.5f animations:^{
            [_wait setAlpha:1.0f]; [_X setAlpha:1.0f];
        }];
    }
}

- (void)doneWaiting {
    if ([stringWithContentsOfLocalFile(@"showLoader") isEqual: @"yes"]) {
        [_wait setAlpha:1.0f];
        [UIView animateWithDuration:0.5f animations:^{
            [_wait setAlpha:0.0f]; [_X setAlpha:0.0f];
        } completion:^(BOOL finished) {
            [_wait setHidden:YES];
        }];
    }
}

- (IBAction)respringDevice:(id)sender {
    respringDevice();
}

- (void)calert:(NSString*)alertTitle alertMessage:(NSString*)alertMessage dismissButton:(NSString*)dismissButton buttonVis:(int)buttonVis dismissBtnAction:(SEL)dismissBtnAction {
    [_dismissAlertBtn setExclusiveTouch:YES];
    if ([alertTitle isEqual: @"Success"]) {
        if (dontRespring == FALSE){[_respringBtn setHidden:NO];}
    } else {
        [_respringBtn setHidden:YES];
    }
    [_cancel setEnabled:NO];
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alertTitle setText:alertTitle];
    [_alertText setText:alertMessage];
    if (buttonVis == 0) {
        [_dismissAlertBtn setHidden:YES];
    } else if (buttonVis == 1) {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:@selector(calertd) forControlEvents:UIControlEventTouchUpInside];
    } else {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:dismissBtnAction forControlEvents:UIControlEventTouchUpInside];
    }
    [_alert setHidden:NO]; [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)calertd {
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    } completion:^(BOOL finished) {
        [_respringBtn setHidden:YES];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];});});
    [_cancel setEnabled:YES];
}

- (IBAction)xBtnPressed:(id)sender {
    [self calertd];
}

- (NSString *)getFE:(NSURL *)url{
    NSString *urlString = [url absoluteString];
    NSArray *componentsArray = [urlString componentsSeparatedByString:@"."];
    NSString *fileExtension = [componentsArray lastObject];
    return fileExtension;
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (void)canRevert {
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" isDirectory:nil]) {
        [UIView animateWithDuration:0.5f animations:^{
            [_revertBtn bgBlueColour];
        }];
        [_revertBtn setEnabled:YES];
    } else {
        [UIView animateWithDuration:0.5f animations:^{
            [_revertBtn bgDisabledColour];
        }];
        [_revertBtn setEnabled:NO];
    }
}

- (void)checkWiFiC {
    [self canRevert];
    if (noWiFi) {
        [UIView animateWithDuration:0.5f animations:^{
            [_change bgDisabledColour];
        }];
        [_change setEnabled:NO];
    } else {
        [UIView animateWithDuration:0.5f animations:^{
            [_change bgBlueColour];
        }];
        [_change setEnabled:YES];
    }
}

NSInteger emoji = -1;

- (void)viewWillAppear:(BOOL)animated {
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" isDirectory:nil]) {
        [_revertBtn bgBlueColour];
        [_revertBtn setEnabled:YES];
    } else {
        [_revertBtn bgDisabledColour];
        [_revertBtn setEnabled:NO];
    }
    emoji = -1;
    [self applyBtn:_change];
    [self applyBtn:_cancel];
    [self applyBtn:_revertBtn];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(checkWiFiC) userInfo:nil repeats:YES];
}

- (IBAction)revert:(id)sender {
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" isDirectory:nil]) {
        [[NSFileManager defaultManager] removeItemAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" error:nil];
        [[NSFileManager defaultManager] moveItemAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" toPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" error:nil];
        [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
    } else {
        [self calert:@"Failed" alertMessage:@"Torngat was unable to locate the old font file." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
    }
}

- (IBAction)cancel:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)change:(id)sender {
    [self waitK];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
        int failure = 0;
        if ([_o selectedSegmentIndex] == 0) {
            emoji = 0;
        } else if ([_o selectedSegmentIndex] == 1) {
            emoji = 1;
        } else if ([_o selectedSegmentIndex] == 2) {
            emoji = 2;
        } else if ([_o selectedSegmentIndex] == 3) {
            emoji = 3;
        }
    method1:;
        NSLog(@"Method 1");
        if (emoji == 0) {
            NSURL *url = [NSURL URLWithString:@"https://1gamerdev.github.io/Torngat-Files/ios11.3.ttc"];
            NSData *receivedData = [NSData dataWithContentsOfURL:url];
            if (receivedData) {
                [self doneWaiting];
                ![[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" isDirectory:nil] && [[NSFileManager defaultManager] moveItemAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" toPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" error:nil];
                [receivedData writeToFile:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" atomically:YES];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                });});
            } else {
                failure = failure + 1;
                if (failure == 2) {
                    goto out0;
                }
                goto method2;
            }
        } else if (emoji == 1) {
            NSURL *url = [NSURL URLWithString:@"https://dl.dropboxusercontent.com/s/v79f1mgqwxw4puy/androidoreo.ttc"];
            NSData *receivedData = [NSData dataWithContentsOfURL:url];
            if (receivedData) {
                [self doneWaiting];
                ![[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" isDirectory:nil] && [[NSFileManager defaultManager] moveItemAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" toPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" error:nil];
                [receivedData writeToFile:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" atomically:YES];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                });});
            } else {
                failure = failure + 1;
                if (failure == 2) {
                    goto out0;
                }
                goto method2;
            }
        } else if (emoji == 2) {
            NSURL *url = [NSURL URLWithString:@"https://dl.dropboxusercontent.com/s/dss5l6912nbqssj/emojione.ttc"];
            NSData *receivedData = [NSData dataWithContentsOfURL:url];
            if (receivedData) {
                [self doneWaiting];
                ![[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" isDirectory:nil] && [[NSFileManager defaultManager] moveItemAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" toPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" error:nil];
                [receivedData writeToFile:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" atomically:YES];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                });});
            } else {
                failure = failure + 1;
                if (failure == 2) {
                    goto out0;
                }
                goto method2;
            }
        } else if (emoji == 3) {
            NSURL *url = [NSURL URLWithString:@"https://dl.dropboxusercontent.com/s/ttsgje898eybmzi/twitter2.4.ttc"];
            NSData *receivedData = [NSData dataWithContentsOfURL:url];
            if (receivedData) {
                [self doneWaiting];
                ![[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" isDirectory:nil] && [[NSFileManager defaultManager] moveItemAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" toPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" error:nil];
                [receivedData writeToFile:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" atomically:YES];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                });});
            } else {
                failure = failure + 1;
                if (failure == 2) {
                    goto out0;
                }
                goto method2;
            }
        } else {
            [self doneWaiting];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                [self calert:@"Failed" alertMessage:@"No emoji was selected." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
            });});
        }
        return;
    method2:;
        NSLog(@"Method 2");
        if (emoji == 0) {
            NSURL *url = [NSURL URLWithString:@"https://1gamerdev.github.io/Torngat-Files/ios11.3.ttc"];
            NSData *receivedData = [NSData dataWithContentsOfURL:url];
            if (receivedData) {
                [self doneWaiting];
                ![[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" isDirectory:nil] && [[NSFileManager defaultManager] moveItemAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" toPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" error:nil];
                [receivedData writeToFile:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" atomically:YES];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                });});
            } else {
                failure = failure + 1;
                if (failure == 2) {
                    goto out0;
                }
                goto method1;
            }
        }
        else if (emoji == 1) {
            NSURL *url = [NSURL URLWithString:@"https://1gamerdev.github.io/Torngat-Files/androidoreo.ttc"];
            NSData *receivedData = [NSData dataWithContentsOfURL:url];
            if (receivedData) {
                [self doneWaiting];
                ![[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" isDirectory:nil] && [[NSFileManager defaultManager] moveItemAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" toPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" error:nil];
                [receivedData writeToFile:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" atomically:YES];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                });});
            } else {
                failure = failure + 1;
                if (failure == 2) {
                    goto out0;
                }
                goto method1;
            }
        }
        else if (emoji == 2) {
            NSURL *url = [NSURL URLWithString:@"https://1gamerdev.github.io/Torngat-Files/emojione.ttc"];
            NSData *receivedData = [NSData dataWithContentsOfURL:url];
            if (receivedData) {
                [self doneWaiting];
                ![[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" isDirectory:nil] && [[NSFileManager defaultManager] moveItemAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" toPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" error:nil];
                [receivedData writeToFile:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" atomically:YES];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                });});
            } else {
                failure = failure + 1;
                if (failure == 2) {
                    goto out0;
                }
                goto method1;
            }
        } else if (emoji == 3) {
            NSURL *url = [NSURL URLWithString:@"https://1gamerdev.github.io/Torngat-Files/twitter2.4.ttc"];
            NSData *receivedData = [NSData dataWithContentsOfURL:url];
            if (receivedData) {
                [self doneWaiting];
                ![[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" isDirectory:nil] && [[NSFileManager defaultManager] moveItemAtPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" toPath:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc.old" error:nil];
                [receivedData writeToFile:@"/System/Library/Fonts/Core/AppleColorEmoji@2x.ttc" atomically:YES];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
                });});
            } else {
                failure = failure + 1;
                if (failure == 2) {
                    goto out0;
                }
                goto method1;
            }
        } else {
            [self doneWaiting];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
                [self calert:@"Failed" alertMessage:@"No emoji was selected." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
            });});
        }
        return;
    out0:;
        [self doneWaiting];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{
            [self calert:@"Failed" alertMessage:@"Torngat was unable to download a required file." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
        });});
        return;
    });});
}

- (IBAction)keybtn:(id)sender {
    [self.view endEditing:YES];
}

@end

@interface bigFullscreenBoi ()
@property (strong, nonatomic) IBOutlet UIButton *respringBtn;

@end

@implementation bigFullscreenBoi

- (IBAction)respringDevice:(id)sender {
    respringDevice();
}

- (void)calert {
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alert setHidden:NO]; [_X setHidden:NO];
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];}
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)viewWillAppear:(BOOL)animated {
    [_titleT setText:bigFullscreenBoiTitle];
    if ([bigFullscreenBoiTitle isEqual: @"Success"]) {
        if (dontRespring == FALSE){[_respringBtn setHidden:NO];}
    } else {
        [_respringBtn setHidden:YES];
    }
    [_text setText:bigFullscreenBoiText];
    [self calert];
}

- (IBAction)cyaBruv:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    } completion:^(BOOL finished) {
        [_respringBtn setHidden:YES];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];[self dismissViewControllerAnimated:NO completion:nil];});});
}

@end

@interface badges ()
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *alertTitle;
@property (strong, nonatomic) IBOutlet UITextView *alertText;
@property (strong, nonatomic) IBOutlet UIButton *dismissAlertBtn;
@property (strong, nonatomic) IBOutlet UIView *colourDisplay;
@property (strong, nonatomic) IBOutlet UIButton *defaultBtn;
@property (strong, nonatomic) IBOutlet UIButton *transparent;
@property (strong, nonatomic) IBOutlet UIButton *respringBtn;
@property (strong, nonatomic) IBOutlet UISlider *opacitySlider;
@property (strong, nonatomic) IBOutlet UILabel *opacityValue;

@end

@implementation badges

float sliderVal;
NSTimer *cu;

- (void)calert:(NSString*)alertTitle alertMessage:(NSString*)alertMessage dismissButton:(NSString*)dismissButton buttonVis:(int)buttonVis dismissBtnAction:(SEL)dismissBtnAction {
    [_dismissAlertBtn setExclusiveTouch:YES];
    [_cancel setEnabled:NO];
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alertTitle setText:alertTitle];
    [_alertText setText:alertMessage];
    if (buttonVis == 0) {
        [_dismissAlertBtn setHidden:YES];
    } else if (buttonVis == 1) {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:@selector(calertd) forControlEvents:UIControlEventTouchUpInside];
    } else {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:dismissBtnAction forControlEvents:UIControlEventTouchUpInside];
    }
    [_alert setHidden:NO]; [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)calertd {
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    } completion:^(BOOL finished) {
        [_respringBtn setHidden:YES];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];});});
    [_cancel setEnabled:YES];
}

- (IBAction)xBtnPressed:(id)sender {
    [self calertd];
}

- (NSString *)getFE:(NSURL *)url{
    NSString *urlString = [url absoluteString];
    NSArray *componentsArray = [urlString componentsSeparatedByString:@"."];
    NSString *fileExtension = [componentsArray lastObject];
    return fileExtension;
}

- (IBAction)changedSliderVal:(id)sender {
    [_opacityValue setText:[NSString stringWithFormat:@"%.01f", _opacitySlider.value]];
}

- (IBAction)useDefault:(id)sender {
    unlink("/var/mobile/Library/Caches/MappedImageCache/Persistent/SBIconBadgeView.BadgeBackground.cpbitmap");
    if (dontRespring == FALSE){[_respringBtn setHidden:NO];}
    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
}

- (IBAction)respringDevice:(id)sender {
    respringDevice();
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (void)viewWillAppear:(BOOL)animated {
    [_colourDisplay setBackgroundColor:hex(0xFF0000, 1.0)];
    [self applyBtn:_change];
    [self applyBtn:_cancel];
    [self applyBtn:_defaultBtn];
    [self applyBtn:_transparent];
    [_respringBtn setHidden:YES];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    cu = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(updateColour) userInfo:nil repeats:YES];
    [cu fire];
}

- (void)viewWillDisappear:(BOOL)animated {
    [cu invalidate];
}

- (void)updateColour {
    unsint rgb = 0;
    NSString *hexv = [_hexf.text stringByReplacingOccurrencesOfString:@"#" withString:@""];
    [[NSScanner scannerWithString:[[[NSString stringWithFormat:@"%s", [hexv UTF8String]] lowercaseString] stringByTrimmingCharactersInSet:[[NSCharacterSet characterSetWithCharactersInString:@"abcdef0123456789"] invertedSet]]] scanHexInt:&rgb];
    if ([hexv length] != 6) {
        float alphav = _opacitySlider.value;
        [_colourDisplay setBackgroundColor:hex(0xFF0000, alphav)];
        [UIView animateWithDuration:0.5f animations:^{
            [_colourDisplay setBackgroundColor:hex(0xFF0000, alphav)];
        }];
        return;
    }
    float alphav = _opacitySlider.value;
    [_colourDisplay setBackgroundColor:[[_colourDisplay backgroundColor] colorWithAlphaComponent:alphav]];
    [UIView animateWithDuration:0.5f animations:^{
        [_colourDisplay setBackgroundColor:hex(rgb, alphav)];
    }];
}

- (IBAction)cancel:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [self dismissViewControllerAnimated:YES completion:nil];
}

int size() {
    int detected;
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        detected = 3;
    } else {
        detected = 2;
    }
    return detected;
}

UIImage *badge;

int bc(const char *colour, BOOL transparent) {
    printf("size: %i\n", size());
    /*
     // size 1.  i dont think any device uses this size but i wrote this code just in case.  contact me if (a) device(s) uses size 1 & which device(s) [it/they] [is/are] and i'll uncomment this.
     if (size() == 1) { UIGraphicsBeginImageContextWithOptions(CGRectMake(0, 0, 12, 12).size, NO, 0.0);
     CGContextRef context = UIGraphicsGetCurrentContext();
     CGContextSetFillColorWithColor(context, [[UIColor blackColor] CGColor]);
     CGRect size;
     if (transparent == FALSE) {
     size =  CGRectMake(0, 0, 12, 12);
     } else {
     size = CGRectMake(0, 0, 0, 0);
     }
     CGContextFillRect(context, size);
     badge = UIGraphicsGetImageFromCurrentImageContext();
     UIGraphicsEndImageContext();
     UIGraphicsBeginImageContextWithOptions(CGSizeMake(12.0, 12.0), NO, 0.0);
     CGRect bounds=(CGRect){CGPointZero, CGSizeMake(12.0, 12.0)};
     [[UIBezierPath bezierPathWithRoundedRect:bounds cornerRadius:6.0f] addClip];
     [badge drawInRect:bounds];
     badge = UIGraphicsGetImageFromCurrentImageContext();
     UIGraphicsEndImageContext();
     else */if (size() == 2) {
         UIGraphicsBeginImageContextWithOptions(CGRectMake(0, 0, 24, 24).size, NO, 0.0);
         CGContextRef context = UIGraphicsGetCurrentContext();
         CGContextSetFillColorWithColor(context, [[UIColor blackColor] CGColor]);
         CGRect size;
         if (transparent == FALSE) {
             size =  CGRectMake(0, 0, 24, 24);
         } else {
             size = CGRectMake(0, 0, 0, 0);
         }
         CGContextFillRect(context, size);
         badge = UIGraphicsGetImageFromCurrentImageContext();
         UIGraphicsEndImageContext();
         UIGraphicsBeginImageContextWithOptions(CGSizeMake(24.0, 24.0), NO, 0.0);
         CGRect bounds=(CGRect){CGPointZero, CGSizeMake(24.0, 24.0)};
         [[UIBezierPath bezierPathWithRoundedRect:bounds cornerRadius:12.0f] addClip];
         [badge drawInRect:bounds];
         badge = UIGraphicsGetImageFromCurrentImageContext();
         UIGraphicsEndImageContext();
     } else if (size() == 3) {
         //UIGraphicsBeginImageContextWithOptions(CGRectMake(0, 0, 48, 48).size, NO, 0.0);
         UIGraphicsBeginImageContextWithOptions(CGRectMake(0, 0, 24, 24).size, NO, 0.0);
         CGContextRef context = UIGraphicsGetCurrentContext();
         CGContextSetFillColorWithColor(context, [[UIColor blackColor] CGColor]);
         CGRect size;
         if (transparent == FALSE) {
             size =  CGRectMake(0, 0, 48, 48);
         } else {
             size = CGRectMake(0, 0, 0, 0);
         }
         CGContextFillRect(context, size);
         badge = UIGraphicsGetImageFromCurrentImageContext();
         UIGraphicsEndImageContext();
         //UIGraphicsBeginImageContextWithOptions(CGSizeMake(48.0, 48.0), NO, 0.0);
         //CGRect bounds=(CGRect){CGPointZero, CGSizeMake(48.0, 48.0)};
         //[[UIBezierPath bezierPathWithRoundedRect:bounds cornerRadius:24.0f] addClip];
         UIGraphicsBeginImageContextWithOptions(CGSizeMake(24.0, 24.0), NO, 0.0);
         CGRect bounds=(CGRect){CGPointZero, CGSizeMake(24.0, 24.0)};
         [[UIBezierPath bezierPathWithRoundedRect:bounds cornerRadius:12.0f] addClip];
         [badge drawInRect:bounds];
         badge = UIGraphicsGetImageFromCurrentImageContext();
         UIGraphicsEndImageContext();
     } else {
         return -2;
     }
    unsint rgb = 0;
    [[NSScanner scannerWithString:[[[NSString stringWithFormat:@"%s", colour] lowercaseString] stringByTrimmingCharactersInSet:[[NSCharacterSet characterSetWithCharactersInString:@"abcdef0123456789"] invertedSet]]] scanHexInt:&rgb];
    CGRect rect = CGRectMake(0, 0, badge.size.width, badge.size.height);
    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0.0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextClipToMask(context, rect, badge.CGImage);
    CGContextSetFillColorWithColor(context, [hex(rgb, sliderVal) CGColor]);
    CGContextFillRect(context, rect);
    badge = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    [badge writeToCPBitmapFile:@"/private/var/mobile/Documents/IconBadgeBackground_Torngat.cpbitmap" flags:1];
    unlink("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/SBIconBadgeView.BadgeBackground.cpbitmap");
    int read_fd = open("/private/var/mobile/Documents/IconBadgeBackground_Torngat.cpbitmap", O_RDONLY, 0);
    int write_fd = open("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/SBIconBadgeView.BadgeBackground.cpbitmap", O_RDWR | O_CREAT | O_APPEND, 0777);
    if(fdopen(read_fd, "r") == NULL) {
        return -1;
    }
    if(fdopen(write_fd, "wb") == NULL) {
        return -1;
    }
    FILE *read_f = fdopen(read_fd, "r");
    FILE *write_f = fdopen(write_fd, "wb");
    size_t write_size;
    size_t read_size;
    while(feof(read_f) == 0) {
        char buff[100];
        if((read_size = fread(buff, 1, 100, read_f)) != 100) {
            if(ferror(read_f) != 0) {
                return -1;
            }
        }
        if((write_size = fwrite(buff, 1, read_size, write_f)) != read_size) {
            return -1;
        }
    }
    fclose(read_f);
    fclose(write_f);
    close(read_fd);
    close(write_fd);
    if (unlink("/private/var/mobile/Documents/IconBadgeBackground_Torngat.cpbitmap") != 0) {
        return -1;
    }
    chown("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/SBIconBadgeView.BadgeBackground.cpbitmap", 501, 501);
    chmod("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/SBIconBadgeView.BadgeBackground.cpbitmap", 0666);
    return 1;
}

- (IBAction)transparent:(id)sender {
    if (bc([_hexf.text UTF8String], TRUE)) {
        if (dontRespring == FALSE){[_respringBtn setHidden:NO];}
        [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
    } else {
        [self calert:@"Failed" alertMessage:@"An error has occurred." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
    }
}

- (IBAction)change:(id)sender {
    NSString *hexv = [_hexf.text stringByReplacingOccurrencesOfString:@"#" withString:@""];
    if (![hexv isEqual: @""]) {
        if ([hexv length] == 6) {
            sliderVal = _opacitySlider.value;
            int ret = bc([_hexf.text UTF8String], FALSE);
            if (ret == 1) {
                if (dontRespring == FALSE){[_respringBtn setHidden:NO];}
                [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
            } else if (ret == -2) {
                [self calert:@"Failed" alertMessage:@"Torngat could not detect the correct badge size." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
            } else {
                [self calert:@"Failed" alertMessage:@"An error has occurred." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
            }
        } else {
            [self calert:@"Failed" alertMessage:@"Invalid hex code." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
        }
    } else {
        [self calert:@"Failed" alertMessage:@"No hex code was supplied." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
    }
}

- (IBAction)keybtn:(id)sender {
    [self.view endEditing:YES];
}

@end

@interface aboutVC ()

@end

@implementation aboutVC

- (void)visualStyle {
    [self.navigationController.navigationBar setValue:@(YES) forKeyPath:@"hidesShadow"];
    if(darkModeIsEnabled()) {
        [_contentDisplay.scrollView setIndicatorStyle:UIScrollViewIndicatorStyleWhite];
        [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
        [self.navigationController.navigationBar setBarTintColor:hex(0x1B2737, 1.0)];
        [self.view setBackgroundColor:hex(0x151E29, 1.0)];
        [_contentDisplay loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[[NSBundle mainBundle] pathForResource:@"darkAbout" ofType:@"html"]]]];
        [_contentDisplay setBackgroundColor:hex(0x151E29, 1.0)];
    } else {
        [_contentDisplay.scrollView setIndicatorStyle:UIScrollViewIndicatorStyleBlack];
        [self.navigationController.navigationBar setBarStyle:UIBarStyleDefault];
        [self.navigationController.navigationBar setBarTintColor:hex(0xF2F2F2, 1.0)];
        [self.view setBackgroundColor:hex(0xFAFAFA, 1.0)];
        [_contentDisplay loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[[NSBundle mainBundle] pathForResource:@"about" ofType:@"html"]]]];
        [_contentDisplay setBackgroundColor:hex(0xFAFAFA, 1.0)];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(visualStyle)     name:@"updatedVisualStyle" object:nil];
    [self visualStyle];
}

@end

@interface settings ()
@property (strong, nonatomic) IBOutlet UISwitch *darkModeSwitch;
@property (strong, nonatomic) IBOutlet UISwitch *loaderSwitch;
@property (strong, nonatomic) IBOutlet UISwitch *autoExploitSwitch;
@property (strong, nonatomic) IBOutlet UILabel *darkModeText;
@property (strong, nonatomic) IBOutlet UILabel *loadingSpinnerText;
@property (strong, nonatomic) IBOutlet UILabel *exploitAutomaticallyText;
@property (strong, nonatomic) IBOutlet UITableViewCell *darkModeCell;
@property (strong, nonatomic) IBOutlet UITableViewCell *loadingSpinnerCell;
@property (strong, nonatomic) IBOutlet UITableViewCell *exploitAutomaticallyCell;
@property (strong, nonatomic) IBOutlet UISwitch *resizeBootlogosSwitch;
@property (strong, nonatomic) IBOutlet UITableViewCell *resizeCell;
@property (strong, nonatomic) IBOutlet UILabel *resizeText;

@end

@implementation settings

- (void)viewWillAppear:(BOOL)animated {
    [self.darkModeCell setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self.loadingSpinnerCell setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self.resizeCell setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self.exploitAutomaticallyCell setTranslatesAutoresizingMaskIntoConstraints:NO];
    if ([stringWithContentsOfLocalFile(@"darkMode") isEqual: @"yes"]) {
        [_darkModeSwitch setOn:YES animated:NO];
    } else {
        [_darkModeSwitch setOn:NO animated:NO];
    }
    if ([stringWithContentsOfLocalFile(@"showLoader") isEqual: @"yes"]) {
        [_loaderSwitch setOn:YES animated:NO];
    } else {
        [_loaderSwitch setOn:NO animated:NO];
    }
    if ([stringWithContentsOfLocalFile(@"autoExploit") isEqual: @"yes"]) {
        [_autoExploitSwitch setOn:YES animated:NO];
    } else {
        [_autoExploitSwitch setOn:NO animated:NO];
    }
    if([stringWithContentsOfLocalFile(@"resizeBootlogos") isEqual: @"yes"]) {
        [_resizeBootlogosSwitch setOn:YES animated:NO];
    } else {
        [_resizeBootlogosSwitch setOn:NO animated:NO];
    }
    if (darkModeIsEnabled()) {
        [self.navigationController.navigationBar setValue:@(YES) forKeyPath:@"hidesShadow"];
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
        [self.parentViewController.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
        [self.parentViewController.navigationController.navigationBar setBarTintColor:hex(0x1B2737, 1.0)];
        [self.view setBackgroundColor:hex(0x151E29, 1.0)];
        _darkModeText.textColor = [UIColor whiteColor];
        _loadingSpinnerText.textColor = [UIColor whiteColor];
        _exploitAutomaticallyText.textColor = [UIColor whiteColor];
        _resizeText.textColor = [UIColor whiteColor];
        _darkModeCell.backgroundColor = hex(0x151E29, 1.0);
        _loadingSpinnerCell.backgroundColor = hex(0x151E29, 1.0);
        _exploitAutomaticallyCell.backgroundColor = hex(0x151E29, 1.0);
        _resizeCell.backgroundColor = hex(0x151E29, 1.0);
    } else {
        [self.navigationController.navigationBar setValue:@(YES) forKeyPath:@"hidesShadow"];
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];
        [self.parentViewController.navigationController.navigationBar setBarStyle:UIBarStyleDefault];
        [self.parentViewController.navigationController.navigationBar setBarTintColor:hex(0xF2F2F2, 1.0)];
        [self.view setBackgroundColor:hex(0xFAFAFA, 1.0)];
        _darkModeText.textColor = [UIColor blackColor];
        _loadingSpinnerText.textColor = [UIColor blackColor];
        _exploitAutomaticallyText.textColor = [UIColor blackColor];
        _resizeText.textColor = [UIColor blackColor];
        _darkModeCell.backgroundColor = hex(0xFAFAFA, 1.0);
        _loadingSpinnerCell.backgroundColor = hex(0xFAFAFA, 1.0);
        _exploitAutomaticallyCell.backgroundColor = hex(0xFAFAFA, 1.0);
        _resizeCell.backgroundColor = hex(0xFAFAFA, 1.0);
    }
    if (!remounted()) {
        [_resizeBootlogosSwitch setEnabled:NO];
        [_resizeText setTextColor:[UIColor grayColor]];
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:@"updatedVisualStyle" object:self];
}

- (void)enableDarkMode {
    [self.navigationController.navigationBar setValue:@(YES) forKeyPath:@"hidesShadow"];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.2f animations:^{
        [self.parentViewController.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
        [self.parentViewController.navigationController.navigationBar setBarTintColor:hex(0x1B2737, 1.0)];
        [self.view setBackgroundColor:hex(0x151E29, 1.0)];
        _darkModeText.textColor = [UIColor whiteColor];
        _loadingSpinnerText.textColor = [UIColor whiteColor];
        _exploitAutomaticallyText.textColor = [UIColor whiteColor];
        _resizeText.textColor = [UIColor whiteColor];
        _darkModeCell.backgroundColor = hex(0x151E29, 1.0);
        _loadingSpinnerCell.backgroundColor = hex(0x151E29, 1.0);
        _exploitAutomaticallyCell.backgroundColor = hex(0x151E29, 1.0);
        _resizeCell.backgroundColor = hex(0x151E29, 1.0);
    }];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"updatedVisualStyle" object:self];
}

- (void)disableDarkMode {
    [self.navigationController.navigationBar setValue:@(YES) forKeyPath:@"hidesShadow"];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];
    [UIView animateWithDuration:0.2f animations:^{
        [self.parentViewController.navigationController.navigationBar setBarStyle:UIBarStyleDefault];
        [self.parentViewController.navigationController.navigationBar setBarTintColor:hex(0xF2F2F2, 1.0)];
        [self.view setBackgroundColor:hex(0xFAFAFA, 1.0)];
        _darkModeText.textColor = [UIColor blackColor];
        _loadingSpinnerText.textColor = [UIColor blackColor];
        _exploitAutomaticallyText.textColor = [UIColor blackColor];
        _resizeText.textColor = [UIColor blackColor];
        _darkModeCell.backgroundColor = hex(0xFAFAFA, 1.0);
        _loadingSpinnerCell.backgroundColor = hex(0xFAFAFA, 1.0);
        _exploitAutomaticallyCell.backgroundColor = hex(0xFAFAFA, 1.0);
        _resizeCell.backgroundColor = hex(0xFAFAFA, 1.0);
    }];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"updatedVisualStyle" object:self];
}

- (IBAction)toggleDarkMode:(id)sender {
    [self.navigationController.navigationBar setValue:@(YES) forKeyPath:@"hidesShadow"];
    if ([_darkModeSwitch isOn]) {
        writeToLocalFile(@"darkMode", @"yes");
        [self enableDarkMode];
    } else {
        writeToLocalFile(@"darkMode", @"no");
        [self disableDarkMode];
    }
}

- (IBAction)toggleLoader:(id)sender {
    if ([_loaderSwitch isOn]) {
        writeToLocalFile(@"showLoader", @"yes");
    } else {
        writeToLocalFile(@"showLoader", @"no");
    }
}

- (IBAction)toggleAutoExploit:(id)sender {
    if ([_autoExploitSwitch isOn]) {
        writeToLocalFile(@"autoExploit", @"yes");
    } else {
        writeToLocalFile(@"autoExploit", @"no");
    }
}

- (IBAction)toggleResizeBootlogos:(id)sender {
    if ([_autoExploitSwitch isOn]) {
        writeToLocalFile(@"resizeBootlogos", @"yes");
    } else {
        writeToLocalFile(@"resizeBootlogos", @"no");
    }
}

@end

@interface dockLine ()
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *alertTitle;
@property (strong, nonatomic) IBOutlet UITextView *alertText;
@property (strong, nonatomic) IBOutlet UIButton *dismissAlertBtn;
@property (strong, nonatomic) IBOutlet UIView *colourDisplay;
@property (strong, nonatomic) IBOutlet UIButton *defaultBtn;
@property (strong, nonatomic) IBOutlet UIButton *transparent;
@property (strong, nonatomic) IBOutlet UIButton *respringBtn;
@property (strong, nonatomic) IBOutlet UISlider *heightSlider;
@property (strong, nonatomic) IBOutlet UILabel *heightValue;

@end

@implementation dockLine

float sliderVal_;

- (void)calert:(NSString*)alertTitle alertMessage:(NSString*)alertMessage dismissButton:(NSString*)dismissButton buttonVis:(int)buttonVis dismissBtnAction:(SEL)dismissBtnAction {
    [_dismissAlertBtn setExclusiveTouch:YES];
    [_cancel setEnabled:NO];
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alertTitle setText:alertTitle];
    [_alertText setText:alertMessage];
    if (buttonVis == 0) {
        [_dismissAlertBtn setHidden:YES];
    } else if (buttonVis == 1) {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:@selector(calertd) forControlEvents:UIControlEventTouchUpInside];
    } else {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:dismissBtnAction forControlEvents:UIControlEventTouchUpInside];
    }
    [_alert setHidden:NO]; [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)calertd {
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    } completion:^(BOOL finished) {
        [_respringBtn setHidden:YES];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];});});
    [_cancel setEnabled:YES];
}

- (IBAction)xBtnPressed:(id)sender {
    [self calertd];
}

- (NSString *)getFE:(NSURL *)url{
    NSString *urlString = [url absoluteString];
    NSArray *componentsArray = [urlString componentsSeparatedByString:@"."];
    NSString *fileExtension = [componentsArray lastObject];
    return fileExtension;
}

- (IBAction)useDefault:(id)sender {
    unlink("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/highlight-0.05a-0.5h.cpbitmap");
    if (dontRespring == FALSE){[_respringBtn setHidden:NO];}
    [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
}

- (IBAction)respringDevice:(id)sender {
    respringDevice();
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (void)viewWillAppear:(BOOL)animated {
    [_colourDisplay setBackgroundColor:hex(0x000000, 1.0)];
    [self applyBtn:_change];
    [self applyBtn:_cancel];
    [self applyBtn:_defaultBtn];
    [self applyBtn:_transparent];
    [_respringBtn setHidden:YES];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [NSTimer scheduledTimerWithTimeInterval:0.4 target:self selector:@selector(updateColour) userInfo:nil repeats:YES];
}

- (void)updateColour {
    unsint rgb = 0;
    NSString *hexv = [_hexf.text stringByReplacingOccurrencesOfString:@"#" withString:@""];
    [[NSScanner scannerWithString:[[[NSString stringWithFormat:@"%s", [hexv UTF8String]] lowercaseString] stringByTrimmingCharactersInSet:[[NSCharacterSet characterSetWithCharactersInString:@"abcdef0123456789"] invertedSet]]] scanHexInt:&rgb];
    if ([hexv length] != 6) {
        [UIView animateWithDuration:0.5f animations:^{
            [_colourDisplay setBackgroundColor:hex(0x000000, 1.0)];
        }];
        return;
    }
    [UIView animateWithDuration:0.5f animations:^{
        [_colourDisplay setBackgroundColor:hex(rgb, 1.0)];
    }];
}

- (IBAction)updateHeightVal:(id)sender {
    [_heightValue setText:[NSString stringWithFormat:@"%.01f", _heightSlider.value]];
}

- (IBAction)cancel:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [self dismissViewControllerAnimated:YES completion:nil];
}

UIImage *line;
int lc(const char *colour, BOOL transparent) {
    float sv = sliderVal_;
         UIGraphicsBeginImageContextWithOptions(CGRectMake(0, 0, 10000, sv).size, NO, 0.0);
         CGContextRef context = UIGraphicsGetCurrentContext();
         CGContextSetFillColorWithColor(context, [[UIColor blackColor] CGColor]);
         CGRect size;
         if (transparent == FALSE) {
             size =  CGRectMake(0, 0, 10000, sv);
         } else {
             size = CGRectMake(0, 0, 0, 0);
         }
         CGContextFillRect(context, size);
         line = UIGraphicsGetImageFromCurrentImageContext();
         UIGraphicsEndImageContext();
         UIGraphicsBeginImageContextWithOptions(CGSizeMake(10000, sv), NO, 0.0);
         CGRect bounds=(CGRect){CGPointZero, CGSizeMake(10000, sv)};
         [line drawInRect:bounds];
         line = UIGraphicsGetImageFromCurrentImageContext();
         UIGraphicsEndImageContext();
    unsint rgb = 0;
    [[NSScanner scannerWithString:[[[NSString stringWithFormat:@"%s", colour] lowercaseString] stringByTrimmingCharactersInSet:[[NSCharacterSet characterSetWithCharactersInString:@"abcdef0123456789"] invertedSet]]] scanHexInt:&rgb];
    CGRect rect = CGRectMake(0, 0, line.size.width, line.size.height);
    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0.0);
    CGContextRef context_ = UIGraphicsGetCurrentContext();
    CGContextClipToMask(context_, rect, line.CGImage);
    CGContextSetFillColorWithColor(context_, [hex(rgb, 1.0) CGColor]);
    CGContextFillRect(context_, rect);
    line = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    [line writeToCPBitmapFile:@"/private/var/mobile/DockLine_Torngat.cpbitmap" flags:1];
    unlink("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/highlight-0.05a-0.5h.cpbitmap");
    NSLog(@"%@", [NSData dataWithContentsOfFile:@"/private/var/mobile/DockLine_Torngat.cpbitmap"]);
    int read_fd = open("/private/var/mobile/DockLine_Torngat.cpbitmap", O_RDONLY, 0);
    int write_fd = open("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/highlight-0.05a-0.5h.cpbitmap", O_RDWR | O_CREAT | O_APPEND, 0777);
    if(fdopen(read_fd, "r") == NULL) {
        return -1;
    }
    if(fdopen(write_fd, "wb") == NULL) {
        return -1;
    }
    FILE *read_f = fdopen(read_fd, "r");
    FILE *write_f = fdopen(write_fd, "wb");
    size_t write_size;
    size_t read_size;
    while(feof(read_f) == 0) {
        char buff[100];
        if((read_size = fread(buff, 1, 100, read_f)) != 100) {
            if(ferror(read_f) != 0) {
                return -1;
            }
        }
        if((write_size = fwrite(buff, 1, read_size, write_f)) != read_size) {
            return -1;
        }
    }
    fclose(read_f);
    fclose(write_f);
    close(read_fd);
    close(write_fd);
    if (unlink("/private/var/mobile/DockLine_Torngat.cpbitmap") != 0) {
        return -1;
    }
    chown("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/highlight-0.05a-0.5h.cpbitmap", 501, 501);
    chmod("/private/var/mobile/Library/Caches/MappedImageCache/Persistent/highlight-0.05a-0.5h.cpbitmap", 0666);
    return 1;
}

- (IBAction)transparent:(id)sender {
    if (lc("000000", TRUE)) {
        if (dontRespring == FALSE){[_respringBtn setHidden:NO];}
        [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
    } else {
        [self calert:@"Failed" alertMessage:@"An error has occurred." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
    }
}

- (IBAction)change:(id)sender {
    NSString *hexv = [_hexf.text stringByReplacingOccurrencesOfString:@"#" withString:@""];
    if (![hexv isEqual: @""]) {
        if ([hexv length] == 6) {
            sliderVal_ = [[NSString stringWithFormat:@"%.01f", _heightSlider.value] floatValue];
            int ret = lc([hexv UTF8String], FALSE);
            if (ret == 1) {
                if (dontRespring == FALSE){[_respringBtn setHidden:NO];}
                [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
            } else if (ret == -2) {
                [self calert:@"Failed" alertMessage:@"Torngat could not detect the correct line size." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
            } else {
                [self calert:@"Failed" alertMessage:@"An error has occurred." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
            }
        } else {
            [self calert:@"Failed" alertMessage:@"Invalid hex code." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
        }
    } else {
        [self calert:@"Failed" alertMessage:@"No hex code was supplied." dismissButton:nil buttonVis:0 dismissBtnAction:nil];
    }
}

- (IBAction)keybtn:(id)sender {
    [self.view endEditing:YES];
}

@end

@interface layout ()
@property (strong, nonatomic) IBOutlet UIView *alert;
@property (strong, nonatomic) IBOutlet UILabel *alertTitle;
@property (strong, nonatomic) IBOutlet UITextView *alertText;
@property (strong, nonatomic) IBOutlet UIButton *dismissAlertBtn;
@property (strong, nonatomic) IBOutlet UITableView *table;
@property (strong,nonatomic) NSArray *content;

@end

@implementation layout

- (void)calert:(NSString*)alertTitle alertMessage:(NSString*)alertMessage dismissButton:(NSString*)dismissButton buttonVis:(int)buttonVis dismissBtnAction:(SEL)dismissBtnAction {
    [_dismissAlertBtn setExclusiveTouch:YES];
    [_cancel setEnabled:NO];
    [_alert setAlpha:0.0]; [_X setAlpha:0.0];
    [_alertTitle setText:alertTitle];
    [_alertText setText:alertMessage];
    if (buttonVis == 0) {
        [_dismissAlertBtn setHidden:YES];
    } else if (buttonVis == 1) {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:@selector(calertd) forControlEvents:UIControlEventTouchUpInside];
    } else {
        [_dismissAlertBtn setHidden:NO];
        [_dismissAlertBtn setTitle:dismissButton forState:UIControlStateNormal];
        [_dismissAlertBtn removeTarget:nil action:NULL forControlEvents:UIControlEventAllEvents];
        [_dismissAlertBtn addTarget:self action:dismissBtnAction forControlEvents:UIControlEventTouchUpInside];
    }
    [_alert setHidden:NO]; [_X setHidden:NO];
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:1.0f]; [_X setAlpha:1.0f];
    }];
}

- (void)calertd {
    [_alert setAlpha:1.0f];
    [_X setAlpha:1.0f];
    [UIView animateWithDuration:0.5f animations:^{
        [_alert setAlpha:0.0f];
        [_X setAlpha:0.0f];
    } completion:^(BOOL finished) {
        [_respringBtn setHidden:YES];
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{[NSThread sleepForTimeInterval:0.5f];dispatch_async(dispatch_get_main_queue(),^{[_alert setHidden:YES];[_X setHidden:YES];});});
    [_cancel setEnabled:YES];
}

- (IBAction)xBtnPressed:(id)sender {
    [self calertd];
}

- (void)applyBtn:(UIButton*)btnId {
    btnId.layer.shadowColor = [[UIColor colorWithRed:0 green:0 blue:0 alpha:0.25f] CGColor];
    btnId.layer.shadowOffset = CGSizeMake(0, 0);
    btnId.layer.shadowOpacity = 1.0f;
    btnId.layer.shadowRadius = 5;
    btnId.layer.masksToBounds = NO;
    btnId.layer.cornerRadius = 10.0f;
    btnId.exclusiveTouch = YES;
}

- (void)viewWillAppear:(BOOL)animated {
    [self applyBtn:_change];
    [self applyBtn:_cancel];
    getDocumentsDirectory();
    BOOL isDir;
    if (![[NSFileManager defaultManager] fileExistsAtPath:[NSString stringWithFormat:@"%@/layouts/", documentsDirectory] isDirectory:&isDir]) {
        createLocalDirectory(@"layouts");
    }
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:YES];
    [self configureTableview];
    self.content = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:[NSString stringWithFormat:@"%@/layouts/", documentsDirectory] error:nil];
}

- (IBAction)cancel:(id)sender {
    if(!darkModeIsEnabled()){[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];}
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)configureTableview {
    self.table.delegate = self;
    self.table.dataSource = self;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _content.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"cellIdentifier";
    UITableViewCell *cell = [self.table dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    cell.textLabel.text =  [_content objectAtIndex:indexPath.row];
    cell.backgroundColor = hex(0x000000, 0.0);
    cell.textLabel.textColor = hex(0xFFFFFF, 1.0);
    //cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

NSString *b;

- (void)yesido {
    [self calertd];
    unlink("/var/mobile/Library/SpringBoard/IconState.plist");
    [[NSMutableDictionary dictionaryWithContentsOfFile:stringWithPathOfLocalFile([NSString stringWithFormat:@"layouts/%@", b])] writeToFile:@"/var/mobile/Library/SpringBoard/IconState.plist" atomically:YES];
    chown("/var/mobile/Library/SpringBoard/IconState.plist", 501, 501);
    chmod("/var/mobile/Library/SpringBoard/IconState.plist", 0666);
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{ [NSThread sleepForTimeInterval:0.5f];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (dontRespring == FALSE){[_respringBtn setHidden:NO];}
            [self calert:@"Success" alertMessage:@"Please respring your device." dismissButton:@"Dismiss" buttonVis:2 dismissBtnAction:@selector(cancel:)];
        });});
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath; {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    b = [NSString stringWithFormat:@"%@", [_content objectAtIndex:indexPath.row]];
    [self calert:@"Confirmation" alertMessage:[NSString stringWithFormat:@"Do you really want to set your home screen layout to the one saved on %@?", [_content objectAtIndex:indexPath.row]] dismissButton:@"Continue" buttonVis:2 dismissBtnAction:@selector(yesido)];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        removeLocalFile([NSString stringWithFormat:@"layouts/%@", [_content objectAtIndex:indexPath.row]]);
        self.content = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:[NSString stringWithFormat:@"%@/layouts/", documentsDirectory] error:nil];
        [self.table reloadData];
    }
}

- (IBAction)respringDevice:(id)sender {
    respringDevice();
}

- (IBAction)change:(id)sender {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd_hh:mm:ss"];
    NSString *d = [NSString stringWithFormat:@"%@", [dateFormatter stringFromDate:[NSDate date]]];
    printf("name: %s\n", d.UTF8String);
    [[NSMutableDictionary dictionaryWithContentsOfFile:@"/var/mobile/Library/SpringBoard/IconState.plist"] writeToFile:stringWithPathOfLocalFile([NSString stringWithFormat:@"layouts/%@", d]) atomically:YES];
    NSLog(@"%@", [NSMutableDictionary dictionaryWithContentsOfFile:stringWithPathOfLocalFile([NSString stringWithFormat:@"layouts/%@", d])]);
    self.content = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:[NSString stringWithFormat:@"%@/layouts/", documentsDirectory] error:nil];
    NSLog(@"%@", _content);
    [self.table reloadData];
}

- (IBAction)keybtn:(id)sender {
    [self.view endEditing:YES];
}

@end
